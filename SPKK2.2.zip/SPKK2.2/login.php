<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SPKK</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        /* Global Styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            height: 100vh;
            background: linear-gradient(135deg, white 50%, #7db3ff 50%);
        }
    </style>

</head>

<body>
    <div class="font-[sans-serif] min-h-screen flex items-center justify-center">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-10 p-6 max-w-4xl w-full rounded-3xl shadow-lg bg-white">

            <!-- Form Section -->
            <div class="p-8 bg-slate-100 rounded-xl shadow-md">
                <h2 class="text-gray-800 text-center text-3xl font-semibold mb-4">Login</h2>
                <form action="login_process.php" method="POST" class="space-y-6">
                    <div>
                        <label class="text-gray-600 text-sm font-medium block">Email</label>
                        <input name="email" type="email" required
                            class="w-full mt-2 text-gray-800 text-sm border border-gray-300 px-4 py-3 rounded-lg outline-none focus:ring-2 focus:ring-blue-500"
                            placeholder="Masukkan Email" />
                    </div>

                    <div>
                        <label class="text-gray-600 text-sm font-medium block">Kata Laluan</label>
                        <div class="relative">
                            <input name="password" type="password" required
                                class="w-full mt-2 text-gray-800 text-sm border border-gray-300 px-4 py-3 rounded-lg outline-none focus:ring-2 focus:ring-blue-500"
                                placeholder="Masukkan Kata Laluan" id="passwordInput" />
                            <button type="button" onclick="togglePassword()"
                                class="absolute right-3 top-3 text-gray-500 hover:text-gray-700 focus:outline-none mt-2">
                                <i id="eyeIcon" class="fas fa-eye"></i>
                            </button>
                        </div>
                    </div>

                    <div class="!mt-8">
                        <input type="submit" value="Log Masuk"
                            class="w-full py-3 px-4 text-sm font-semibold rounded-lg text-white bg-blue-600 hover:bg-blue-700 focus:outline-none transition-colors duration-200">
                    </div>

                    <p class="text-gray-600 text-sm text-center">Tiada Akaun?
                        <a href="register.php" class="text-blue-600 hover:underline font-medium">Daftar Sekarang</a>
                    </p>
                </form>
            </div>

            <!-- Logo Section -->
            <div class="flex items-center justify-center">
                <img src="img/logo-spkk.png" alt="logo" class="w-80 h-auto md:w-80" />
            </div>

        </div>
    </div>

    <!--script-->
    <script>
        function togglePassword() {
            const passwordInput = document.getElementById("passwordInput");
            const eyeIcon = document.getElementById("eyeIcon");

            if (passwordInput.type === "password") {
                passwordInput.type = "text";
                eyeIcon.classList.remove("fa-eye");
                eyeIcon.classList.add("fa-eye-slash");
            } else {
                passwordInput.type = "password";
                eyeIcon.classList.remove("fa-eye-slash");
                eyeIcon.classList.add("fa-eye");
            }
        }
    </script>







</body>

</html>
