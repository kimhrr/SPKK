<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "spkk";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve the image
$id = $_GET['id']; // Assuming you have an ID parameter in the URL
$sql = "SELECT image_data, image_type FROM images WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$stmt->bind_result($imageData, $imageType);
$stmt->fetch();

if ($imageData) {
    // Set the correct MIME type for the image
    header("Content-Type: $imageType");
    echo $imageData;
} else {
    echo "Image not found.";
}

$stmt->close();
$conn->close();
?>
