<?php
session_start();

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "spkk";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form data is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get user input
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Prepare and execute query to fetch user
    $sql = "SELECT id, email, pass, role FROM user WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();

        // Verify password
        if (password_verify($password, $user['pass'])) {
            // Set session variables
            $_SESSION['id'] = $user['id'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['role'] = $user['role'];

            // Redirect based on role
            if ($user['role'] == 'Pelajar') {
                header("Location: home_page.php");  // Pelajar dashboard
            } elseif ($user['role'] == 'Pensyarah') {
                header("Location: home_page.php");  // Pensyarah dashboard
            } else {
                header("Location: home_page_super.php");  // Admin dashboard
            }
            exit();
        } else {
            // Invalid password
            header("Location: login.php?error=Invalid email or password");
            exit();
        }
    } else {
        // Invalid email
        header("Location: login.php?error=Invalid email or password");
        exit();
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
}
?>
