<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SPKK | Pensyarah Bertugas</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100;300;400;500;700;900&display=swap"
        rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        body {
            font-family: 'Montserrat', sans-serif;
        }

        /* Styling for active link */
        .active {
            background-color: #ebf8ff;
            /* Sama macam warna hover */
            color: #ebf8ff;
            /* Warna text untuk active link */
        }
    </style>
</head>

<body class="bg-[#F0FFFF] flex-auto">
<div class="min-h-screen flex">
        <!-- Sidebar -->
        <aside id="sidebar"
            class="bg-white shadow-2xl transition-all duration-300 ease-in-out w-64 border-r border-gray-200"
            aria-label="Sidebar" role="navigation">
            <div class="h-full px-6 py-5 flex flex-col">
                <div class="flex items-center justify-between mb-8">
                    <div class="flex items-center gap-3">
                        <img id="logoImg" src="img/logo-spkk.png" alt="Logo"
                            class="h-30 w-auto transition-opacity duration-300">
                    </div>
                    <button id="toggleBtn"
                        class="p-2 rounded-lg hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        aria-label="Toggle Sidebar" aria-expanded="true">
                        <i class="fas fa-chevron-left transition-transform duration-300"></i>
                    </button>
                </div>

                <nav class="space-y-3 flex-grow">
                    <a href="home_page.php"
                        class="flex items-center p-3 text-gray-700 rounded-lg hover:bg-blue-50 group transition-colors hover:text-blue-600"
                        data-page="home_page.php">
                        <i class="fas fa-home w-6 h-6"></i>
                        <span class="ml-3 font-medium transition-opacity duration-300">Home</span>
                    </a>
                    <a href="permohonan.php"
                        class="flex items-center p-3 text-gray-700 rounded-lg hover:bg-blue-50 group transition-colors hover:text-blue-600"
                        data-page="permohonan.php">
                        <i class="fa-regular fa-pen-to-square w-6 h-6"></i>
                        <span class="ml-3 font-medium transition-opacity duration-300">Permohonan</span>
                    </a>
                    <a href="rekod_sakit.php"
                        class="flex items-center p-3 text-gray-700 rounded-lg hover:bg-blue-50 group transition-colors hover:text-blue-600"
                        data-page="sijil_sakit.php">
                        <i class="fa-solid fa-file-medical w-6 h-6"></i>
                        <span class="ml-3 font-medium transition-opacity duration-300">Rekod Sakit</span>
                    </a>
                    <a href="Pensyarah_bertugas.php"
                        class="flex items-center p-3 text-gray-700 rounded-lg hover:bg-blue-50 group transition-colors hover:text-blue-600"
                        data-page="Pensyarah_bertugas.php">
                        <i class="fas fa-users w-6 h-6"></i>
                        <span class="ml-3 font-medium transition-opacity duration-300">Pensyarah Bertugas</span>
                    </a>
                </nav>

                <div class="mt-auto border-t pt-4 space-y-4">
                    <a href="javascript:void(0);" id="logoutBtn"
                        class="flex items-center p-3 text-red-600 rounded-lg hover:bg-red-50 group transition-colors">
                        <i class="fas fa-sign-out-alt w-6 h-6"></i>
                        <span class="ml-3 font-medium transition-opacity duration-300">Logout</span>
                    </a>
                </div>
            </div>
        </aside>

        <!-- Main Content (No change here) -->
        <main class="flex-1 p-8">
            <header class="flex border-b border-black sm:px-0 bg-[#F0FFFF] min-h-[40px] tracking-wide relative z-80">
                <div class="flex flex-wrap items-center gap-5 w-full">
                    <a href="javascript:void(0)" class="text-1xl">SPKK-KV KUALA SELANGOR</a>
                </div>
                <button id="toggleSidebar" class="lg:hidden ml-auto p-2">
                    <svg class="w-7 h-7" fill="#000" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                        <path fill-rule="evenodd"
                            d="M3 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 10a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 15a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z"
                            clip-rule="evenodd"></path>
                    </svg>
                </button>
            </header>

            <section class="mt-8">
                <h1 class="text-2xl font-semibold mb-4">PENSYARAH BERTUGAS</h1>
                <p class="mb-6">Sila masukkan minggu pertama dan minggu terakhir</p>

                <!-- Form Tarikh -->
                <div class="flex gap-4 mb-6">
                    <input type="date" class="p-2 border border-gray-300 rounded-md w-40" placeholder="From Date">
                    <input type="date" class="p-2 border border-gray-300 rounded-md w-40" placeholder="To Date">
                    <button class="bg-blue-500 text-white p-2 rounded-md">Cari</button>
                </div>

                <!-- Table Pensyarah Bertugas -->
                <div class="overflow-x-auto">
                    <table
                        class="min-w-full bg-white border border-gray-200 rounded-lg border-separate border-spacing-0">
                        <thead class="bg-gray-800 text-white">
                            <tr>
                                <th class="py-3 px-6 text-left border bg-[#216565] rounded-tl-lg">Minggu</th>
                                <th class="py-3 px-6 text-left border bg-[#216565]">Nama Pensyarah</th>
                                <th class="py-3 px-6 text-left border bg-[#216565]">Tarikh Mula</th>
                                <th class="py-3 px-6 text-left border bg-[#216565] rounded-tr-lg">Tarikh Akhir</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr class="bg-gray-100">
                                <td colspan="4"
                                    class="text-center py-4 text-gray-500 border border-gray-200 rounded-b-lg">Tiada
                                    Rekod Pensyarah Bertugas ..</td>
                            </tr>
                        </tbody>
                    </table>
                </div>

            </section>
        </main>

    </div>

    <!-- Scripts -->
    <script>
        const sidebar = document.getElementById('sidebar');
        const toggleBtn = document.getElementById('toggleBtn');
        const icon = toggleBtn.querySelector('i');
        const textElements = sidebar.querySelectorAll('span');
        const logoImg = document.getElementById('logoImg'); // Select elemen logo

        toggleBtn.addEventListener('click', () => {
            const isExpanded = sidebar.classList.contains('w-64');
            sidebar.classList.toggle('w-64');
            sidebar.classList.toggle('w-20');
            icon.classList.toggle('rotate-180');

            // Toggle visibility of text elements and logo
            textElements.forEach(el => {
                if (isExpanded) {
                    el.classList.add('hidden');
                } else {
                    el.classList.remove('hidden');
                }
            });

            if (isExpanded) {
                logoImg.classList.add('hidden'); // Sembunyikan logo bila sidebar tutup
            } else {
                logoImg.classList.remove('hidden'); // Tunjukkan logo bila sidebar buka
            }

            toggleBtn.setAttribute('aria-expanded', !isExpanded);
        });

        // Escape key to close sidebar
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                sidebar.classList.remove('w-64');
                sidebar.classList.add('w-20');
                icon.classList.add('rotate-180');

                textElements.forEach(el => el.classList.add('hidden'));
                logoImg.classList.add('hidden'); // Sembunyikan logo bila Escape ditekan
                toggleBtn.setAttribute('aria-expanded', 'false');
            }
        });

        // Active link detection
        document.addEventListener("DOMContentLoaded", () => {
            const currentPage = window.location.pathname.split("/").pop();
            const links = sidebar.querySelectorAll("a");

            links.forEach(link => {
                const page = link.getAttribute("data-page");
                if (page === currentPage) {
                    link.classList.add("active");
                }
            });
        });

        // Ambil button logout
        document.getElementById('logoutBtn').addEventListener('click', function() {
            // Panggil SweetAlert2 untuk pengesahan logout
            Swal.fire({
                title: 'Anda pasti?',
                text: 'Anda akan log keluar.',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Ya, Logout',
                cancelButtonText: 'Batal',
                reverseButtons: true
            }).then((result) => {
                if (result.isConfirmed) {
                    // Jika pengguna klik 'Ya, Logout', redirect ke logout.php
                    window.location.href = 'login.php';
                }
            });
        });
    </script>
</body>

</html>
