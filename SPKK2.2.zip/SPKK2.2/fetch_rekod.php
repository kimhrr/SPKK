<?php
session_start();

// Database connection
$servername = 'localhost';
$username = 'root';
$password = '';
$dbname = 'spkk';

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

// Check if the user is logged in (student ID is set in session)
if (!isset($_SESSION['id'])) {
    // Redirect to login page if not logged in
    header('Location: login.php');
    exit();
}

// Fetch the student ID from the session
$id = $_SESSION['id'];

// DataTable server-side processing
$columns = ['rekod_id', 'sebab', 'datetime', 'status'];
$sql = 'SELECT rekod_id, sebab, datetime, status FROM rekod_klinik WHERE id = ?';

// Prepare and execute the SQL statement with the student's ID
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $id); // Bind the student ID as an integer
$stmt->execute();
$result = $stmt->get_result();

$data = [];
$index = 1;

while ($row = $result->fetch_assoc()) {
    $status = $row['status'] ? 'Approved' : 'Pending';
    $data[] = [
        'bil' => $index++,
        'sebab' => $row['sebab'],
        'datetime' => $row['datetime'],
        'status' => $status,
    ];
}

// Return JSON for DataTables
$response = [
    'data' => $data,
];

echo json_encode($response);

$stmt->close();
$conn->close();
?>
