<?php
session_start();

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if the user is logged in
if (!isset($_SESSION['id']) || $_SESSION['role'] != 'Admin') {
    // Redirect to login page if not logged in
    header('Location: login.php');
    exit();
}

// Fetch user data from the session
$user_id = $_SESSION['id'];

include 'conn.php';

$query = 'SELECT * FROM pelajar';
$stmt = $conn->prepare($query);

if ($stmt === false) {
    die('Error preparing statement: ' . $conn->error);
}

$stmt->execute();
$result = $stmt->get_result();
$records = $result->num_rows > 0 ? $result->fetch_all(MYSQLI_ASSOC) : [];
?>

<!DOCTYPE html>
<html lang="en">



<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.17.1/xlsx.full.min.js"></script>
    <!-- Font Awesome CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
        function exportToExcel() {
            const data = [
                ["ID", "Name", "Email", "IC No", "Class", "Gender"], // Header row
                <?php foreach ($records as $record): ?>[<?= $record['id'] ?>, "<?= htmlspecialchars($record['nama']) ?>",
                    "<?= htmlspecialchars($record['email']) ?>", "<?= htmlspecialchars($record['no_ic']) ?>",
                    "<?= htmlspecialchars($record['kelas']) ?>", "<?= htmlspecialchars($record['jantina']) ?>"],
                <?php endforeach; ?>
            ];

            const ws = XLSX.utils.aoa_to_sheet(data);
            const wb = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(wb, ws, "Students");
            XLSX.writeFile(wb, "students_data.xlsx");
        }
    </script>
    <script>
        // Function to handle the search bar input and filter table rows by Name
        function searchTable() {
            const input = document.getElementById("searchInput");
            const filter = input.value.toLowerCase();
            const table = document.getElementById("studentTable");
            const rows = table.getElementsByTagName("tr");

            // Loop through all table rows, starting from 1 to skip the header row
            for (let i = 1; i < rows.length; i++) {
                const cells = rows[i].getElementsByTagName("td");
                const nameCell = cells[0]; // Assuming the "Name" column is the first column (index 0)

                if (nameCell) {
                    const nameText = nameCell.textContent || nameCell.innerText;

                    // If the search term is found in the name column, display the row
                    if (nameText.toLowerCase().includes(filter)) {
                        rows[i].style.display = "";
                    } else {
                        rows[i].style.display = "none";
                    }
                }
            }
        }
    </script>
    <script>
        function importFromExcel(event) {
            const file = event.target.files[0];

            if (file) {
                const reader = new FileReader();

                reader.onload = function(e) {
                    const data = new Uint8Array(e.target.result);
                    const workbook = XLSX.read(data, {
                        type: 'array'
                    });

                    // Get the first sheet name
                    const firstSheetName = workbook.SheetNames[0];
                    const worksheet = workbook.Sheets[firstSheetName];

                    // Convert sheet data to JSON format
                    const jsonData = XLSX.utils.sheet_to_json(worksheet, {
                        header: 1
                    });

                    // Display JSON data in console (you can customize this to display in HTML)
                    console.log(jsonData);

                    // Optionally, display the data in an HTML table
                    displayDataInTable(jsonData);
                };

                reader.readAsArrayBuffer(file);
            }
        }

        function displayDataInTable(data) {
            const table = document.createElement('table');
            table.classList.add('table', 'table-bordered');

            data.forEach(row => {
                const tr = document.createElement('tr');
                row.forEach(cell => {
                    const td = document.createElement('td');
                    td.textContent = cell;
                    tr.appendChild(td);
                });
                table.appendChild(tr);
            });

            // Append the table to a div or any HTML element in your page
            const container = document.getElementById('tableContainer');
            container.innerHTML = ''; // Clear previous content
            container.appendChild(table);
        }
    </script>


    <title>LIST STUDENT</title>
</head>

<body>
    <header class='flex border-b py-4 px-4 sm:px-10 bg-white font-[sans-serif] min-h-[70px] tracking-wide relative z-50'>
        <div class='flex flex-wrap items-center gap-5 w-full'>
            <a href="#"><img src="img/logo-spkk.png" alt="logo" class='w-36'></a>
            </a>

            <div id="collapseMenu"
                class='max-lg:hidden lg:!block max-lg:w-full max-lg:fixed max-lg:before:fixed max-lg:before:bg-black max-lg:before:opacity-50 max-lg:before:inset-0 max-lg:before:z-50'>
                <button id="toggleClose" class='lg:hidden fixed top-2 right-4 z-[100] rounded-full bg-white p-3'>
                    <svg xmlns="http://www.w3.org/2000/svg" class="w-4 fill-black" viewBox="0 0 320.591 320.591">
                        <path
                            d="M30.391 318.583a30.37 30.37 0 0 1-21.56-7.288c-11.774-11.844-11.774-30.973 0-42.817L266.643 10.665c12.246-11.459 31.462-10.822 42.921 1.424 10.362 11.074 10.966 28.095 1.414 39.875L51.647 311.295a30.366 30.366 0 0 1-21.256 7.288z"
                            data-original="#000000"></path>
                        <path
                            d="M287.9 318.583a30.37 30.37 0 0 1-21.257-8.806L8.83 51.963C-2.078 39.225-.595 20.055 12.143 9.146c11.369-9.736 28.136-9.736 39.504 0l259.331 257.813c12.243 11.462 12.876 30.679 1.414 42.922-.456.487-.927.958-1.414 1.414a30.368 30.368 0 0 1-23.078 7.288z"
                            data-original="#000000"></path>
                    </svg>
                </button>

                <ul
                    class='lg:flex lg:ml-14 lg:gap-x-5 max-lg:space-y-3 max-lg:fixed max-lg:bg-white max-lg:w-1/2 max-lg:min-w-[300px] max-lg:top-0 max-lg:left-0 max-lg:p-6 max-lg:h-full max-lg:shadow-md max-lg:overflow-auto z-50'>
                    <li class='max-lg:border-b max-lg:py-3 px-3'>
                        <a href='home_page_super.php'
                            class='lg:hover:text-[#007bff] text-[#007bff] block font-semibold text-[15px]'>Laman
                            Utama</a>
                    </li>
                    <li class='max-lg:border-b max-lg:py-3 px-3'><a href='super_pemohonan_pelajar.php'
                            class='lg:hover:text-[#007bff] text-gray-500 block font-semibold text-[15px]'>Pemohonan
                            Pelajar</a>
                    </li>
                    <li class='max-lg:border-b max-lg:py-3 px-3'><a href='super_rekod_sakit.php'
                            class='lg:hover:text-[#007bff] text-gray-500 block font-semibold text-[15px]'>Rekod
                            Sakit</a>
                    </li>
                    <li class='max-lg:border-b max-lg:py-3 px-3'>
                        <a href='super_list.php'
                            class='lg:hover:text-[#007bff] text-gray-500 block font-semibold text-[15px]'>Pengurusan
                            Pelajar</a>
                    </li>
                </ul>
            </div>

            <button id="toggleOpen" class='lg:hidden ml-auto'>
                <svg class="w-7 h-7" fill="#000" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd"
                        d="M3 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 10a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 15a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z"
                        clip-rule="evenodd"></path>
                </svg>
            </button>

            <div class='flex lg:ml-auto max-lg:w-full'>
                <a href="logout.php"
                    class="flex items-center p-3 text-red-600 rounded-lg hover:bg-red-50 group transition-colors">
                    <i class="fas fa-sign-out-alt w-6 h-6"></i>
                    <span class="ml-3 font-medium transition-opacity duration-300">Logout</span>
                </a>
            </div>
        </div>
    </header>

    <div class="font-[sans-serif] space-x-4 ml-11 mt-4 flex items-center justify-between">
        <!-- Left Side: Buttons and File Input -->
        <div class="flex items-center space-x-4">
            <!-- Button: Tambah Pelajar Baru -->
            <button type="button" onclick="window.location.href='register.php'"
                class="px-5 py-2.5 rounded-lg text-sm tracking-wider font-medium border border-current outline-none bg-blue-700 hover:bg-transparent text-white hover:text-blue-700 transition-all duration-300">
                Tambah Pelajar Baru
            </button>

            <!-- Button: Export to Excel -->
            <button type="button" onclick="exportToExcel()"
                class="px-5 py-2.5 rounded-lg text-sm tracking-wider font-medium border border-current outline-none bg-green-600 hover:bg-transparent text-white hover:text-green-600 transition-all duration-300">
                Export to Excel
            </button>

            <!-- Hidden input for Excel file import -->
            <input type="file" id="excelFileInput" accept=".xlsx, .xls" style="display: none;"
                onchange="importFromExcel(event)">

            <!-- Button and File Input: Import from Excel -->
            <div
                class="bg-white text-[#333] flex items-center shadow-[0_2px_10px_-3px_rgba(6,81,237,0.3)] p-1 min-w-[300px] w-max font-[sans-serif] rounded-md overflow-hidden mx-2">
                <div class="px-4 flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 612.675 612.675">
                        <path
                            d="M581.209 223.007 269.839 530.92c-51.592 51.024-135.247 51.024-186.839 0-51.592-51.023-51.592-133.737 0-184.761L363.248 69.04c34.402-34.009 90.15-34.009 124.553 0 34.402 34.008 34.402 89.166 0 123.174l-280.249 277.12c-17.19 17.016-45.075 17.016-62.287 0-17.19-16.993-17.19-44.571 0-61.587L394.37 161.42l-31.144-30.793-249.082 246.348c-34.402 34.009-34.402 89.166 0 123.174 34.402 34.009 90.15 34.009 124.552 0l280.249-277.12c51.592-51.023 51.592-133.737 0-184.761-51.593-51.023-135.247-51.023-186.839 0L36.285 330.784l1.072 1.071c-53.736 68.323-49.012 167.091 14.5 229.88 63.512 62.79 163.35 67.492 232.46 14.325l1.072 1.072 326.942-323.31-31.122-30.815z"
                            data-original="#000000" />
                    </svg>
                    <p class="text-sm ml-3">Document.excel</p>
                </div>
                <label for="uploadFile1"
                    class="bg-gray-800 hover:bg-gray-700 text-white text-sm px-3 py-2.5 outline-none rounded-md cursor-pointer ml-auto w-max block">Upload</label>
                <input type="file" id="uploadFile1" class="hidden" />
            </div>
        </div>

        <!-- Right Side: Search Bar -->
        <div
            class="bg-white flex px-1 py-1 rounded-full border border-blue-500 overflow-hidden max-w-md font-[sans-serif]">
            <input type="text" id="searchInput" placeholder="Search by Name..."
                class="w-full outline-none bg-white pl-4 text-sm" oninput="searchTable()">
            <button type="button"
                class="bg-blue-600 hover:bg-blue-700 transition-all text-white text-sm rounded-full px-5 py-2.5">
                Search
            </button>
        </div>
    </div>


    </div>

    <!-- table -->
    <div class="font-[sans-serif] overflow-x-auto gap-y-1 px-6 mt-11 ">
        <table id="studentTable" class="min-w-full bg-white">
            <thead class="bg-gray-800 whitespace-nowrap">
                <tr>
                    <th class="p-4 text-left text-sm font-medium text-white">
                        Nama
                    </th>
                    <th class="p-4 text-left text-sm font-medium text-white">
                        Email
                    </th>
                    <th class="p-4 text-left text-sm font-medium text-white">
                        No. IC
                    </th>
                    <th class="p-4 text-left text-sm font-medium text-white">
                        Kelas
                    </th>
                    <th class="p-4 text-left text-sm font-medium text-white">
                        Jantina
                    </th>
                    <th class="p-4 text-left text-sm font-medium text-white">
                        Tindakan
                    </th>
                </tr>
            </thead>

            <tbody class="whitespace-nowrap">
                <?php if (count($records) > 0): ?>
                <?php foreach ($records as $record): ?>
                <tr class="even:bg-blue-50">
                    <td class="p-4 text-sm text-black">
                        <?= htmlspecialchars(!empty($record['nama']) ? $record['nama'] : 'No Data') ?></td>
                    <td class="p-4 text-sm text-black">
                        <?= htmlspecialchars(!empty($record['email']) ? $record['email'] : 'No Data') ?></td>
                    <td class="p-4 text-sm text-black">
                        <?= htmlspecialchars(!empty($record['no_ic']) ? $record['no_ic'] : 'No Data') ?></td>
                    <td class="p-4 text-sm text-black">
                        <?= htmlspecialchars(!empty($record['kelas']) ? $record['kelas'] : 'No Data') ?></td>
                    <td class="p-4 text-sm text-black">
                        <?= htmlspecialchars(!empty($record['jantina']) ? $record['jantina'] : 'No Data') ?></td>
                    <td class="p-4 text-sm text-black">
                        <button onclick="editStudent(<?= $record['id'] ?>)"
                            class="fas fa-edit text-blue-600 hover:text-blue-800"></button>
                        <button onclick="deleteStudent(<?= $record['id'] ?>)"
                            class="fas fa-trash-alt text-red-600 hover:text-red-800 ml-3"></button>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php else: ?>
                <tr>
                    <td colspan="6" class="p-4 text-center text-sm text-gray-500">No records found.</td>
                </tr>
                <?php endif; ?>
            </tbody>
            <script>
                function editStudent(id) {
                    // Redirect to the edit page for the specific student
                    window.location.href = 'edit_pelajar.php?id=' + id;
                }

                function deleteStudent(id) {
                    Swal.fire({
                        title: 'Are you sure?',
                        text: "You won't be able to revert this!",
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Yes, delete it!'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            // Redirect to a delete handler script, passing student ID
                            window.location.href = 'delete_pelajar.php?id=' + id;
                        }
                    });
                }
            </script>
        </table>
    </div>
</body>

</html>
