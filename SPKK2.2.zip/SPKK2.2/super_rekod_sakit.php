<?php
session_start();

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if the user is logged in
if (!isset($_SESSION['id']) || $_SESSION['role'] != 'Admin') {
    // Redirect to login page if not logged in
    header('Location: login.php');
    exit();
}

// Connect to the Database
include 'conn.php';

// Query to join tables and retrieve data
$sql = "
SELECT pelajar.id AS id, pelajar.nama AS nama, pelajar.kelas AS kelas,
       request_status.tarikh, request_status.sebab,
       request_status.status, request_status.request_id AS request_id
FROM pelajar
JOIN request_status ON pelajar.id = request_status.id
JOIN rekod_sakit ON request_status.request_id = rekod_sakit.request_id";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.17.1/xlsx.full.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" integrity="sha384-k6RqeWeci5ZR/Lv4MR0sA0FfDOMwF4Wqcu60Pz3/1iErhMdQ1Zx6MDl0PpibNokd" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <title>LIST STUDENT</title>
</head>

<body class="bg-gray-100">
<header class='flex border-b py-4 px-4 sm:px-10 bg-white font-[sans-serif] min-h-[70px] tracking-wide relative z-50'>
        <div class='flex flex-wrap items-center gap-5 w-full'>
            <a href="#"><img src="img/logo-spkk.png" alt="logo" class='w-36'></a>
            <div id="collapseMenu"
                class='max-lg:hidden lg:!block max-lg:w-full max-lg:fixed max-lg:before:fixed max-lg:before:bg-black max-lg:before:opacity-50 max-lg:before:inset-0 max-lg:before:z-50'>
                <button id="toggleClose" class='lg:hidden fixed top-2 right-4 z-[100] rounded-full bg-white p-3'>
                    <svg xmlns="http://www.w3.org/2000/svg" class="w-4 fill-black" viewBox="0 0 320.591 320.591">
                        <path
                            d="M30.391 318.583a30.37 30.37 0 0 1-21.56-7.288c-11.774-11.844-11.774-30.973 0-42.817L266.643 10.665c12.246-11.459 31.462-10.822 42.921 1.424 10.362 11.074 10.966 28.095 1.414 39.875L51.647 311.295a30.366 30.366 0 0 1-21.256 7.288z"
                            data-original="#000000"></path>
                        <path
                            d="M287.9 318.583a30.37 30.37 0 0 1-21.257-8.806L8.83 51.963C-2.078 39.225-.595 20.055 12.143 9.146c11.369-9.736 28.136-9.736 39.504 0l259.331 257.813c12.243 11.462 12.876 30.679 1.414 42.922-.456.487-.927.958-1.414 1.414a30.368 30.368 0 0 1-23.078 7.288z"
                            data-original="#000000"></path>
                    </svg>
                </button>
                <ul
                    class='lg:flex lg:ml-14 lg:gap-x-5 max-lg:space-y-3 max-lg:fixed max-lg:bg-white max-lg:w-1/2 max-lg:min-w-[300px] max-lg:top-0 max-lg:left-0 max-lg:p-6 max-lg:h-full max-lg:shadow-md max-lg:overflow-auto z-50'>
                    <li class='max-lg:border-b max-lg:py-3 px-3'>
                        <a href='home_page_super.php'
                            class='lg:hover:text-[#007bff] text-[#007bff] block font-semibold text-[15px]'>Laman
                            Utama</a>
                    </li>
                    <li class='max-lg:border-b max-lg:py-3 px-3'><a href='super_pemohonan_pelajar.php'
                            class='lg:hover:text-[#007bff] text-gray-500 block font-semibold text-[15px]'>Pemohonan
                            Pelajar</a>
                    </li>
                    <li class='max-lg:border-b max-lg:py-3 px-3'><a href='super_rekod_sakit.php'
                            class='lg:hover:text-[#007bff] text-gray-500 block font-semibold text-[15px]'>Rekod
                            Sakit</a>
                    </li>
                    <li class='max-lg:border-b max-lg:py-3 px-3'>
                        <a href='super_list.php'
                            class='lg:hover:text-[#007bff] text-gray-500 block font-semibold text-[15px]'>Pengurusan
                            Pelajar</a>
                    </li>
                </ul>
            </div>
            <button id="toggleOpen" class='lg:hidden ml-auto'>
                <svg class="w-7 h-7" fill="#000" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd"
                        d="M3 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 10a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 15a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z"
                        clip-rule="evenodd"></path>
                </svg>
            </button>
            <div class='flex lg:ml-auto max-lg:w-full'>
                <a href="logout.php"
                    class="flex items-center p-3 text-red-600 rounded-lg hover:bg-red-50 group transition-colors">
                    <i class="fas fa-sign-out-alt w-6 h-6"></i>
                    <span class="ml-3 font-medium transition-opacity duration-300">Logout</span>
                </a>
            </div>
        </div>
    </header>

    <div class="container mx-auto p-4">
    <div class="overflow-x-auto bg-white shadow-md rounded-lg">
        <table class="min-w-full bg-white border border-gray-200">
            <thead class="bg-gray-100">
                <tr>
                    <th class="py-3 px-6 text-left text-gray-700 uppercase font-semibold text-sm">Bil</th>
                    <th class="py-3 px-6 text-left text-gray-700 uppercase font-semibold text-sm">Pelajar</th>
                    <th class="py-3 px-6 text-left text-gray-700 uppercase font-semibold text-sm">Kelas</th>
                    <th class="py-3 px-6 text-left text-gray-700 uppercase font-semibold text-sm">Tarikh</th>
                    <th class="py-3 px-6 text-left text-gray-700 uppercase font-semibold text-sm">Sebab</th>
                    <th class="py-3 px-6 text-center text-gray-700 uppercase font-semibold text-sm">Status</th>
                    <th class="py-3 px-6 text-center text-gray-700 uppercase font-semibold text-sm">Tindakan</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $bil = 1;
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr class='border-b border-gray-200 bg-gray-50 text-sm'>";
                        echo "<td class='py-3 px-6 text-gray-800'>" . $bil++ . "</td>";
                        echo "<td class='py-3 px-6 text-gray-800'>" . $row['nama'] . "</td>";
                        echo "<td class='py-3 px-6 text-gray-800'>" . $row['kelas'] . "</td>";
                        echo "<td class='py-3 px-6 text-gray-800'>" . $row['tarikh'] . "</td>";
                        echo "<td class='py-3 px-6 text-gray-800'>" . $row['sebab'] . "</td>";
                        echo "<td class='py-3 px-6 text-center text-gray-800'>" . $row['status'] . "</td>";
                        echo "<td class='py-3 px-6 text-center flex justify-center gap-2'>";
                        echo "<button class='bg-green-500 text-white px-4 py-1 rounded hover:bg-green-600' onclick='uploadImagePopup(" . $row['request_id'] . ")'>Muat Naik Gambar</button>";
                        echo "<button class='bg-blue-500 text-white px-4 py-1 rounded hover:bg-blue-600 show-image' data-request-id='" . $row['request_id'] . "'><i class='fas fa-eye'></i></button>";
                        echo "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='7' class='py-3 px-6 text-center text-gray-800'>No records found.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>

<script>
        function uploadImagePopup(requestId) {
            Swal.fire({
                title: 'Muat Naik Gambar',
                html: `
            <form id="imageUploadForm" enctype="multipart/form-data">
                <input type="file" id="imageInput" name="image" accept="image/*" class="swal2-input" style="width: auto;" required>
                <input type="hidden" name="request_id" value="${requestId}">
            </form>
        `,
                showCancelButton: true,
                confirmButtonText: 'Upload',
                preConfirm: () => {
                    const form = document.getElementById('imageUploadForm');
                    const formData = new FormData(form);

                    return fetch('upload_image.php', {
                            method: 'POST',
                            body: formData
                        })
                        .then(response => response.json())
                        .then(data => {
                            if (!data.success) {
                                throw new Error(data.message || 'Failed to upload image');
                            }
                            return data;
                        })
                        .catch(error => {
                            Swal.showValidationMessage(`Request failed: ${error}`);
                        });
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    Swal.fire('Success!', 'Image uploaded successfully', 'success');
                }
            });
        }

        // Handle the "Show Image" button click
        document.addEventListener('DOMContentLoaded', function() {
            const buttons = document.querySelectorAll('.show-image');

            buttons.forEach(button => {
                button.addEventListener('click', function() {
                    const requestId = this.getAttribute('data-request-id');

                    // Send AJAX request to get the image
                    fetch(`get_image.php?request_id=${requestId}`)
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                // Display the image using SweetAlert
                                Swal.fire({
                                    title: 'Image',
                                    imageUrl: 'data:' + data.image_type + ';base64,' +
                                        data.image_data,
                                    imageAlt: 'Uploaded Image',
                                    showCloseButton: true
                                });
                            } else {
                                // Show error if image is not found
                                Swal.fire('Error', data.message, 'error');
                            }
                        })
                        .catch(error => {
                            Swal.fire('Error', 'Failed to load image', 'error');
                        });
                });
            });
        });
    </script>

<?php $conn->close(); ?>