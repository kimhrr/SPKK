<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>SPKK</title>

    <!--font awesome-->
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css"
    />

    <!--css file-->
    <link rel="stylesheet" href="styles.css" />
  </head>
  <body>
    <div class="sidebar close">
      <div class="logo">
        <i class="fab fa-trade-federation"></i>
        <span class="logo-name">SPKK</span>
      </div>

      <ul class="nav-list">
        <li>
          <a href="#">
            <i class="fab fa-microsoft"></i>
            <span class="link-name">Dashboard</span>
          </a>

          <ul class="sub-menu blank">
            <li><a href="#" class="link-name">Dashboard</a></li>
          </ul>
        </li>

        <li>
          <div class="icon-link">
            <a href="student.php">
              <i class="fa-solid fa-code-branch"></i>
              <span class="link-name">STUDENT</span>
            </a>
            <i class="fas fa-"></i>
          </div>

          <ul class="sub-menu">
            <li><a href="#" class="link-name"></a></li>
            <li><a href="#"></a></li>
            <li><a href="#"></a></li>
            <li><a href="#"></a></li>
          </ul>
        </li>

        <li>
          <div class="icon-link">
            <a href="#">
              <i class="fab fa-"></i>
              <span class="link-name"></span>
            </a>
            <i class="fas fa-"></i>
          </div>

          <ul class="sub-menu">
            <li><a href="#" class="link-name"></a></li>
            <li><a href="#"></a></li>
            <li><a href="#"></a></li>
            <li><a href="#"></a></li>
          </ul>
        </li>

        <li>
          <a href="#">
            <i class="fas fa-"></i>
            <span class="link-name"></span>
          </a>

          <ul class="sub-menu blank">
            <li><a href="#" class="link-name"></a></li>
          </ul>
        </li>

        <li>
          <a href="#">
            <i class="fas fa-"></i>
            <span class="link-name"></span>
          </a>

          <ul class="sub-menu blank">
            <li><a href="#" class="link-name"></a></li>
          </ul>
        </li>

        <li>
          <div class="icon-link">
            <a href="#">
              <i class="fas fa-"></i>
              <span class="link-name"></span>
            </a>
            <i class="fas fa-caret-down arrow"></i>
          </div>

          <ul class="sub-menu">
            <li><a href="#" class="link-name"></a></li>
            <li><a href="#"></a></li>
            <li><a href="#"></a></li>
            <li><a href="#"></a></li>
          </ul>
        </li>

        <li>
          <a href="#">
            <i class="fas fa-"></i>
            <span class="link-name"></span>
          </a>

          <ul class="sub-menu blank">
            <li><a href="#" class="link-name">Saved</a></li>
          </ul>
        </li>

        <li>
          <a href="#">
            <i class="fas fa-"></i>
            <span class="link-name"></span>
          </a>

          <ul class="sub-menu blank">
            <li><a href="#" class="link-name"></a></li>
          </ul>
        </li>

        <li>
          <a href="#">
            <i class="fas fa-"></i>
            <span class="link-name"></span>
          </a>

          <ul class="sub-menu blank">
            <li><a href="#" class="link-name"></a></li>
          </ul>
        </li>

        <li>
          <div class="profile-details">
            <div class="profile-content">
              <img src="profile.jpg" alt="" />
            </div>

            <div class="name-job">
              <div class="name"></div>
              <div class="job"></div>
            </div>
            <i class="fas fa-"></i>
          </div>
        </li>
      </ul>
    </div>

    <div class="home-section">
      <div class="home-content">
        <i class="fas fa-bars"></i>
        <span class="text"></span>
      </div>
    </div>

    <script src="app.js"></script>
  </body>
</html>
