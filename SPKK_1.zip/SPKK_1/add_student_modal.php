<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <center><img src="img/logokvks.png" width="300px" height="80px" alt="Logo"></center>
        <h4 class="modal-title text-center">Add New Student</h4>
      </div>
      <div class="modal-body">
        <form action="add.php" method="POST" enctype="multipart/form-data">
          <div class="form-row">
            <div class="form-group col-md-6">
              <label for="card_no">NRIC</label>
              <input type="text" class="form-control" id="card_no" name="card_no" placeholder="Enter NRIC Number" maxlength="12" required>
            </div>
            <div class="form-group col-md-6">
              <label for="user_phone">Mobile No.</label>
              <input type="text" class="form-control" id="user_phone" name="user_phone" placeholder="Enter 10-digit Mobile no." maxlength="10" required>
            </div>
          </div>

          <div class="form-row">
            <div class="form-group col-md-6">
              <label for="user_first_name">First Name</label>
              <input type="text" class="form-control" id="user_first_name" name="user_first_name" placeholder="Enter First Name">
            </div>
            <div class="form-group col-md-6">
              <label for="user_last_name">Last Name</label>
              <input type="text" class="form-control" id="user_last_name" name="user_last_name" placeholder="Enter Last Name">
            </div>
          </div>

          <div class="form-row">
            <div class="form-group col-md-6">
              <label for="user_email">Email Id</label>
              <input type="email" class="form-control" id="user_email" name="user_email" placeholder="Enter Email id">
            </div> 
            <div class="form-group col-md-6">
              <label for="image">Image</label>
              <input type="file" class="form-control" id="image" name="image">
            </div>
          </div>

          <div class="form-group">
            <input type="hidden" value="Unblocked" name="status">
            <input type="hidden" value="No" name="card_status">
            <input type="hidden" value="0" name="balance">
          </div>

          <div class="form-group">
            <button type="submit" name="submit" class="btn btn-primary btn-block">Add New Student</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
