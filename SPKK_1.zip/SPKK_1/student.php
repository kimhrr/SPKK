<?php
include('db.php');
include('functions.php');

$studentData = fetchStudentData($con);

// Function to render modals for each student
function renderModals($data) {
    while ($row = mysqli_fetch_array($data)) {
        $id = $row['id'];
        $name = $row['u_f_name'] . ' ' . $row['u_l_name'];
        $image = $row['image'];

        echo "
        <!-- View Modal -->
        <div id='view$id' class='modal fade' role='dialog'>
            <div class='modal-dialog'>
                <div class='modal-content'>
                    <div class='modal-header'>
                        <button type='button' class='close' data-dismiss='modal'>&times;</button>
                        <h4 class='modal-title text-center'>View Card Activation</h4>
                    </div>
                    <div class='modal-body'>
                        <div class='text-center'>
                            <img src='upload_images/$image' style='height:250px;width:250px;' class='img-thumbnail'>
                        </div>
                        <div class='form-group'>
                            <label>First Name</label>
                            <input type='text' class='form-control' value='{$row['u_f_name']}' readonly>
                        </div>
                        <div class='form-group'>
                            <label>Last Name</label>
                            <input type='text' class='form-control' value='{$row['u_l_name']}' readonly>
                        </div>
                        <div class='form-group'>
                            <label>Card</label>
                            <input type='text' class='form-control' value='{$row['u_card']}' readonly>
                        </div>
                        <div class='form-group'>
                            <label>Phone</label>
                            <input type='text' class='form-control' value='{$row['u_phone']}' readonly>
                        </div>
                        <div class='form-group'>
                            <label>Family</label>
                            <input type='text' class='form-control' value='{$row['u_family']}' readonly>
                        </div>
                        <div class='form-group'>
                            <label>Staff ID</label>
                            <input type='text' class='form-control' value='{$row['staff_id']}' readonly>
                        </div>
                    </div>
                    <div class='modal-footer'>
                        <button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Delete Modal -->
        <div id='delete$id' class='modal fade' role='dialog'>
            <div class='modal-dialog'>
                <div class='modal-content'>
                    <div class='modal-header'>
                        <button type='button' class='close' data-dismiss='modal'>&times;</button>
                        <h4 class='modal-title text-center'>Are you sure?</h4>
                    </div>
                    <div class='modal-body text-center'>
                        <a href='delete.php?id=$id' class='btn btn-danger'>Delete</a>
                    </div>
                </div>
            </div>
        </div>
        ";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SPKK</title>
    <!-- SweetAlert2 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <!-- SweetAlert2 JS -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="//cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="styles.css">
    <!-- jQuery and Bootstrap JS -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
    <div class="sidebar close">
        <div class="logo">
            <i class="fab fa-trade-federation"></i>
            <span class="logo-name">SPKK</span>
        </div>
        <ul class="nav-list">
            <li>
                <a href="#">
                    <i class="fab fa-microsoft"></i>
                    <span class="link-name">Dashboard</span>
                </a>
                <ul class="sub-menu blank">
                    <li><a href="#" class="link-name">Dashboard</a></li>
                </ul>
            </li>
            <!-- Add more navigation items here -->
        </ul>
    </div>

    <div class="home-section">
        <div class="home-content">
            <i class="fas fa-bars"></i>
            <span class="text">Student Management</span>
        </div>

        <div class="container">
            <img src="" alt="" width="350px"><br><br>
            <a href="#" class="btn btn-primary"><i class="fa fa-arrow-circle-left"></i></a>
            <button class="btn btn-primary" type="button" data-toggle="modal" data-target="#myModal">
                <i class="fa fa-plus"></i> Add New Student
            </button>
            <a href="#" class="btn btn-success pull-right"><span class="glyphicon glyphicon-print"></span> Print PDF</a>
            <hr>
            <table class="table table-bordered table-striped table-hover" id="myTable">
                <thead>
                    <tr>
                        <th class="text-center" scope="col">S.L</th>
                        <th class="text-center" scope="col">Name</th>
                        <th class="text-center" scope="col">NRIC</th>
                        <th class="text-center" scope="col">Phone</th>
                        <th class="text-center" scope="col">View</th>
                        <th class="text-center" scope="col">Edit</th>
                        <th class="text-center" scope="col">Delete</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $i = 0;
                    mysqli_data_seek($studentData, 0); // Reset pointer to reuse result set
                    while ($row = mysqli_fetch_array($studentData)) {
                        $sl = ++$i;
                        $id = $row['id'];
                        $name = $row['u_f_name'] . ' ' . $row['u_l_name'];
                        $card = $row['u_card'];
                        $phone = $row['u_phone'];
                        $staff_id = $row['staff_id'];

                        echo "
                        <tr>
                            <td class='text-center'>$sl</td>
                            <td class='text-left'>$name</td>
                            <td class='text-left'>$card</td>
                            <td class='text-left'>$phone</td>
                            <td class='text-center'>
                                <a href='#' class='btn btn-success mr-3 profile' data-toggle='modal' data-target='#view$id' title='Profile'>
                                    <i class='fa-solid fa-address-card' aria-hidden='true'></i>
                                </a>
                            </td>
                            <td class='text-center'>
                                <a href='#' class='btn btn-warning mr-3 edituser' data-toggle='modal' data-target='#edit$id' title='Edit'>
                                    <i class='fa-solid fa-pencil'></i>
                                </a>
                            </td>
                            <td class='text-center'>
                                <button class='btn btn-danger deleteuser' title='Delete' data-id='$id'>
                                    <i class='fa-solid fa-trash' aria-hidden='true'></i>
                                </button>
                            </td>
                        </tr>
                        ";
                    }
                    ?>
                </tbody>
            </table>

            <form method="post" action="export.php">
                <input type="submit" name="export" class="btn btn-success" value="Export Data">
            </form>
        </div>
    </div>


    <script>
    $(document).ready(function() {
        $('#myTable').DataTable();

        // SweetAlert for delete confirmation
        $('.deleteuser').on('click', function() {
            var studentId = $(this).data('id');
            var row = $(this).closest('tr');

            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: 'delete.php',
                        type: 'GET',
                        data: { id: studentId },
                        success: function(response) {
                            // Assuming the response is a success message
                            Swal.fire(
                                'Deleted!',
                                'The student record has been deleted.',
                                'success'
                            ).then(() => {
                                // Remove the row from the table
                                row.remove();
                            });
                        },
                        error: function() {
                            Swal.fire(
                                'Failed!',
                                'There was an error deleting the student record.',
                                'error'
                            );
                        }
                    });
                }
            });
        });
    });
    </script>

    <!-- View modal -->
    <?php
    $get_data = "SELECT * FROM card_activation";
    $run_data = mysqli_query($con, $get_data);
    while ($row = mysqli_fetch_array($run_data)) {
        $id = $row['id'];
        $u_card = $row['u_card'];
        $u_f_name = $row['u_f_name'];
        $u_l_name = $row['u_l_name'];
        $u_phone = $row['u_phone'];
        $u_family = $row['u_family'];
        $u_staff_id = $row['staff_id'];
        $image = $row['image'];
        echo "
        <div id='view$id' class='modal fade' role='dialog'>
            <div class='modal-dialog'>
                <div class='modal-content'>
                    <div class='modal-header'>
                        <button type='button' class='close' data-dismiss='modal'>×</button>
                        <h4 class='modal-title text-center'>View Card Activation</h4>
                    </div>
                    <div class='modal-body'>
                        <div class='text-center'>
                            <img src='upload_images/$image' style='height:250px;width:250px;' class='img-thumbnail'>
                        </div>
                        <div class='form-group'>
                            <label>First Name</label>
                            <input type='text' class='form-control' value='$u_f_name' readonly>
                        </div>
                        <div class='form-group'>
                            <label>Last Name</label>
                            <input type='text' class='form-control' value='$u_l_name' readonly>
                        </div>
                        <div class='form-group'>
                            <label>Card</label>
                            <input type='text' class='form-control' value='$u_card' readonly>
                        </div>
                        <div class='form-group'>
                            <label>Phone</label>
                            <input type='text' class='form-control' value='$u_phone' readonly>
                        </div>
                        <div class='form-group'>
                            <label>Family</label>
                            <input type='text' class='form-control' value='$u_family' readonly>
                        </div>
                        <div class='form-group'>
                            <label>Staff ID</label>
                            <input type='text' class='form-control' value='$u_staff_id' readonly>
                        </div>
                    </div>
                    <div class='modal-footer'>
                        <button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
                    </div>
                </div>
            </div>
        </div>";
    }
    ?>

    <?php include('add_student_modal.php'); ?>

    <!-- DataTables and custom scripts -->
    <script src="//cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
    <script>
    $(document).ready(function() {
        $('#myTable').DataTable();
    });
    </script>
</body>
</html>
