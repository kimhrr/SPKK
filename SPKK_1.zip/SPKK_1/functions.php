<?php
function fetchStudentData($con) {
    $query = "SELECT * FROM card_activation ORDER BY 1 DESC";
    return mysqli_query($con, $query);
}
