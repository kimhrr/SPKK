<?php
session_start();

// Configuration
$host = 'localhost'; // or your database host
$dbname = 'login'; // your database name
$username = 'root'; // your database username
$password = ''; // your database password

// Check if user is already logged in
if (isset($_SESSION['user_id'])) {
    header("Location: Dashboard.php");
    exit();
}

// Check if form has been submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Create a connection to the database
    $conn = new mysqli($host, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Get user input from form
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Prepare and execute query to find user
    $sql = $conn->prepare("SELECT * FROM users WHERE email = ? AND password = ?");
    $sql->bind_param("ss", $email , $password);
    $sql->execute();
    $result = $sql->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();

        // Verify password
        if (password_verify($password, $user['password'])) {
            // Password is correct, start session
            $_SESSION['user_id'] = $user['id'];
            header("Location: Dashboard.php");
            exit();
        } else {
            // Password is incorrect
            $error_message = "Kata laluan tidak betul.";
        }
    } else {
        // Email not found
        $error_message = "Tiada pengguna dengan alamat email tersebut.";
    }

    // Close connection
    $sql->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Laman Web Kesihatan</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="login-container">
        <h1>Selamat Datang ke PSPK</h1>

        <?php if (isset($error_message)): ?>
            <p class="error-message"><?php echo htmlspecialchars($error_message); ?></p>
        <?php endif; ?>

        <form class="login-form" action="login.php" method="POST">
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
            
            <label for="password">Kata Laluan:</label>
            <input type="password" id="password" name="password" required>
            
            <button type="submit">Log Masuk</button>
            
            <div class="extra-options">
                <a href="/forgot-password">Lupa Kata Laluan?</a>
                <a href="/register">Buat Akaun</a>
            </div>
        </form>
    </div>
</body>
</html>

