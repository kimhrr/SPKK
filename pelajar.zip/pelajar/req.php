<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>REQUESTPAGE</title>

    <!-- SweetAlert2 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">

    <!-- DataTables CSS -->
    <link rel="stylesheet" href="//cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <!-- Custom CSS -->
    <link rel="stylesheet" href="../css/styles.css">
    <link rel="stylesheet" href="../css/bootstrapcustom.css">

    <!-- jQuery and Bootstrap JS -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

    <!-- Additional JS Libraries -->
    <script src="//cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <style>
        .carousel-container {
            width: 80%; /* Adjust based on your design needs */
            margin: 30px auto;
            position: relative;
            overflow: hidden;
        }

        .carousel-images {
            display: flex;
            width: 100%; /* Adjust width to 100% of the container */
            transition: transform 0.5s ease;
        }

        .carousel-image {
            flex: 1 0 100%; /* Each image takes up 100% of the container width */
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .carousel-images img {
            width: 100%; /* Image takes up the full width of its container */
            height: auto;
            object-fit: cover;
        }

        .carousel-buttons {
            position: absolute;
            top: 50%;
            width: 100%;
            display: flex;
            justify-content: space-between;
            transform: translateY(-50%);
        }

        .carousel-button {
            background-color: rgba(0, 0, 0, 0.5);
            border: none;
            color: white;
            padding: 10px;
            cursor: pointer;
        }

        .carousel-button:hover {
            background-color: rgba(0, 0, 0, 0.7);
        }
    </style>
</head>

<body>
    <div class="sidebar close">
        <div class="logo">
            <i class="fab fa-trade-federation"></i>
            <span class="logo-name">SPKK</span>
        </div>
        <ul class="nav-list">

       <li>
                <a href="homepage_student.php">
                    <i class="fab fa-microsoft"></i>
                    <span class="link-name">HOME</span>
                </a>
                <ul class="sub-menu blank">
                  <li><a href="" class="link-name">HOME</a></li>
                </ul>
        </li>

        <li>
                <a href="req.php">
                    <i class="fab fa-code-branch"></i>
                    <span class="link-name">REQUEST PAGE</span>
                </a>
                <ul class="sub-menu blank">
                  <li><a href="" class="link-name">REQUEST PAGE</a></li>
                </ul>
        </li>

        <li>
                <a href="lectureduty.php">
                    <i class="fab fa-odnoklassniki"></i>
                    <span class="link-name">LECTURE INFO</span>
                </a>
                <ul class="sub-menu blank">
                  <li><a href="" class="link-name">LECTURE INFO</a></li>
                </ul>
        </li>
            <!-- Add more navigation items here -->
        </ul>
    </div>

    <div class="home-section">
        <div class="home-content">
            <i class="fas fa-bars"></i>
            <span class="text">Request Page</span>
        </div>

        <!--REQUEST FORM HERE-->

    

    <?php include '../includes/footer.php'; ?>
</body>

</html>
