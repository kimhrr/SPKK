<?php
session_start();

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if the user is logged in
if (!isset($_SESSION['id'])) {
    // Redirect to login page if not logged in
    header('Location: login.php');
    exit();
}

// Fetch user data from the session
$user_id = $_SESSION['id'];

include 'conn.php'; // Ensure connection is successful

// Query to get user details from the user table
$query = 'SELECT nama, email, kelas FROM pelajar WHERE id = ?';
$stmt = $conn->prepare($query);
if ($stmt === false) {
    die('Error preparing statement: ' . $conn->error);
}

$stmt->bind_param('i', $user_id); // Binding the user_id to the query
$stmt->execute();
$result = $stmt->get_result();

// Check if data was retrieved
if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
} else {
    echo 'No user data found.';
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SPKK | Home</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100;300;400;500;700;900&display=swap"
        rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <style>
        body {
            font-family: 'Montserrat', sans-serif;
        }

        /* Styling for active link */
        .active {
            background-color: #ebf8ff;
            color: #ebf8ff;
        }
    </style>
</head>

<body class="bg-[#F0FFFF] flex-auto">
    <div class="min-h-screen flex">
        <!-- Sidebar -->
        <aside id="sidebar"
            class="bg-white shadow-2xl transition-all duration-300 ease-in-out w-64 border-r border-gray-200"
            aria-label="Sidebar" role="navigation">
            <div class="h-full px-6 py-5 flex flex-col">
                <div class="flex items-center justify-between mb-8">
                    <div class="flex items-center gap-3">
                        <img id="logoImg" src="img/logo-spkk.png" alt="Logo"
                            class="h-30 w-auto transition-opacity duration-300">
                    </div>
                    <button id="toggleBtn"
                        class="p-2 rounded-lg hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        aria-label="Toggle Sidebar" aria-expanded="true">
                        <i class="fas fa-chevron-left transition-transform duration-300"></i>
                    </button>
                </div>

                <nav class="space-y-3 flex-grow">
                    <a href="home_page.php"
                        class="flex items-center p-3 text-gray-700 rounded-lg hover:bg-blue-50 group transition-colors hover:text-blue-600"
                        data-page="home_page.php">
                        <i class="fas fa-home w-6 h-6"></i>
                        <span class="ml-3 font-medium transition-opacity duration-300">Home</span>
                    </a>
                    <a href="permohonan.php"
                        class="flex items-center p-3 text-gray-700 rounded-lg hover:bg-blue-50 group transition-colors hover:text-blue-600"
                        data-page="permohonan.php">
                        <i class="fa-regular fa-pen-to-square w-6 h-6"></i>
                        <span class="ml-3 font-medium transition-opacity duration-300">Permohonan</span>
                    </a>
                    <a href="rekod_sakit.php"
                        class="flex items-center p-3 text-gray-700 rounded-lg hover:bg-blue-50 group transition-colors hover:text-blue-600"
                        data-page="sijil_sakit.php">
                        <i class="fa-solid fa-file-medical w-6 h-6"></i>
                        <span class="ml-3 font-medium transition-opacity duration-300">Rekod Sakit</span>
                    </a>
                    <a href="Pensyarah_bertugas.php"
                        class="flex items-center p-3 text-gray-700 rounded-lg hover:bg-blue-50 group transition-colors hover:text-blue-600"
                        data-page="Pensyarah_bertugas.php">
                        <i class="fas fa-users w-6 h-6"></i>
                        <span class="ml-3 font-medium transition-opacity duration-300">Pensyarah Bertugas</span>
                    </a>
                </nav>

                <div class="mt-auto border-t pt-4 space-y-4">
                    <a href="javascript:void(0);" id="logoutBtn"
                        class="flex items-center p-3 text-red-600 rounded-lg hover:bg-red-50 group transition-colors">
                        <i class="fas fa-sign-out-alt w-6 h-6"></i>
                        <span class="ml-3 font-medium transition-opacity duration-300">Logout</span>
                    </a>
                </div>
            </div>
        </aside>

        <main class="content flex-1 p-8">
            <header class="flex border-b border-black sm:px-0 bg-[#F0FFFF] min-h-[40px] tracking-wide relative z-80">
                <div class="flex flex-wrap items-center gap-5 w-full">
                    <a href="javascript:void(0)" class="text-1xl">SPKK-KV KUALA SELANGOR</a>
                </div>
            </header>

            <section class="mt-5 max-w-1xl mx-auto main-content" id="mainContent">

                <p class="nama-user text-1xl font-semibold">
                    Hai, <?php echo $user['nama']; ?>!
                </p>

                <br>

                <!-- Maklumat Pelajar -->
                <div class="borang-permohonan bg-gray-200 rounded-md p-4">
                    <div class="header-borang font-semibold bg-[#216565] rounded-md py-3 mb-4">
                        <h3 class="ml-3 text-white">Maklumat Pelajar</h3>
                    </div>

                    <div class="grid gap-y-2 px-3 w-full">
                        <!-- Nama Row -->
                        <div class="grid grid-cols-4 gap-2">
                            <div class="bg-[#008080] text-white px-4 py-3 rounded-lg font-medium text-sm">Nama</div>
                            <div class="bg-white text-black px-4 py-3 rounded-lg text-sm col-span-3 text-left">
                                <?php echo $user['nama']; ?>
                            </div>
                        </div>


                        <!-- Kelas Row -->
                        <div class="grid grid-cols-4 gap-2">
                            <div class="bg-[#008080] text-white px-4 py-3 rounded-lg font-medium text-sm">Kelas
                            </div>
                            <div class="bg-white text-black px-4 py-3 rounded-lg text-sm col-span-3 text-left">
                                <?php echo $user['kelas']; ?>
                            </div>
                        </div>

                        <!-- Email Row -->
                        <div class="grid grid-cols-4 gap-2">
                            <div class="bg-[#008080] text-white px-4 py-3 rounded-lg font-medium text-sm">Email
                            </div>
                            <div class="bg-white text-black px-4 py-3 rounded-lg text-sm col-span-3 text-left">
                                <?php echo $user['email']; ?>
                            </div>
                        </div>
                    </div>

                </div>
            </section>

            <br>

            <!-- Borang Permohonan -->
            <h2 class="borang font-semibold mb-2">
                PERMOHONAN PELAJAR KE KLINIK
            </h2>

            <!-- Info Box -->

            <div class="font-[sans-serif] space-y-6">
                <div class="flex items-start max-sm:flex-col bg-blue-100 text-blue-800 p-4 rounded-lg relative mb-5"
                    role="alert">
                    <div class="flex items-center max-sm:mb-2">
                        <svg xmlns="http://www.w3.org/2000/svg" class="w-[18px] fill-blue-500 inline mr-3"
                            viewBox="0 0 23.625 23.625">
                            <path
                                d="M11.812 0C5.289 0 0 5.289 0 11.812s5.289 11.813 11.812 11.813 11.813-5.29 11.813-11.813S18.335 0 11.812 0zm2.459 18.307c-.608.24-1.092.422-1.455.548a3.838 3.838 0 0 1-1.262.189c-.736 0-1.309-.18-1.717-.539s-.611-.814-.611-1.367c0-.215.015-.435.045-.659a8.23 8.23 0 0 1 .147-.759l.761-2.688c.067-.258.125-.503.171-.731.046-.23.068-.441.068-.633 0-.342-.071-.582-.212-.717-.143-.135-.412-.201-.813-.201-.196 0-.398.029-.605.09-.205.063-.383.12-.529.176l.201-.828c.498-.203.975-.377 1.43-.521a4.225 4.225 0 0 1 1.29-.218c.731 0 1.295.178 1.692.53.395.353.594.812.594 1.376 0 .117-.014.323-.041.617a4.129 4.129 0 0 1-.152.811l-.757 2.68a7.582 7.582 0 0 0-.167.736 3.892 3.892 0 0 0-.073.626c0 .356.079.599.239.728.158.129.435.194.827.194.185 0 .392-.033.626-.097.232-.064.4-.121.506-.17l-.203.827zm-.134-10.878a1.807 1.807 0 0 1-1.275.492c-.496 0-.924-.164-1.28-.492a1.57 1.57 0 0 1-.533-1.193c0-.465.18-.865.533-1.196a1.812 1.812 0 0 1 1.28-.497c.497 0 .923.165 1.275.497.353.331.53.731.53 1.196 0 .467-.177.865-.53 1.193z"
                                data-original="#030104" />
                        </svg>
                        <strong class="font-bold text-sm">Perhatian!</strong>
                    </div>

                    <span class="block sm:inline text-sm ml-4 mr-8 max-sm:ml-0 max-sm:mt-2">Sila semak sebelum
                        menghantar.</span>

                    <svg xmlns="http://www.w3.org/2000/svg"
                        class="w-7 hover:bg-blue-200 rounded-lg transition-all p-2 cursor-pointer fill-blue-500 absolute right-4 top-1/2 -translate-y-1/2"
                        viewBox="0 0 320.591 320.591">
                    </svg>
                </div>

            </div>

            <div class="borang-permohonan bg-gray-200 rounded-md mb-6">
                <div class="header-borang font-semibold bg-[#216565] rounded-md py-4">
                    <h3 class="ml-3 text-white">
                        BORANG PERMOHONAN PELAJAR KE KLINIK
                    </h3>
                </div>

                <div class="form-word ml-5 mt-3 font-light">
                    <p>
                        Sekiranya anda memerlukan rawatan perubatan di klinik, sila kemukakan alasan anda. Pastikan
                        anda
                        nyatakan sebab yang jelas.
                    </p>

                    <form action="mohon_process.php" method="POST"
                        class="max-w-md mx-auto w-full font-[sans-serif] mt-1">
                        <!-- Date and Dropdown Fields Side by Side -->
                        <div class="grid grid-cols-2 gap-4 mb-4">
                            <!-- Date Input Field -->
                            <div>
                                <label for="date" class="block text-sm font-medium text-gray-700">Tarikh
                                    Permohonan:</label>
                                <input type="date" id="date" name="date_field" required
                                    class="p-4 bg-white w-full text-sm border rounded border-red-500 outline-[#007bff]">
                            </div>

                            <!-- Dropdown Field -->
                            <div>
                                <label class="text-gray-800 text-sm mb-2 block">Waktu</label>
                                <select name="kelas"
                                    class="text-gray-800 bg-white border border-gray-300 w-full text-sm px-4 py-3 rounded-md outline-blue-500"
                                    required>
                                    <option value="" disabled selected>Pilih waktu anda ingin ke klinik.
                                    </option>
                                    <option value="0880">0800</option>
                                    <option value="1400">1400</option>
                                </select>
                            </div>
                        </div>

                        <!-- Textarea Field -->
                        <div class="w-full mb-4">
                            <label for="textarea" class="block text-sm font-medium text-gray-700">Sila nyatakan
                                permohonan anda:</label>
                            <textarea id="textarea" name="textarea_field" placeholder="Sila nyatakan permohonan anda."
                                class="p-4 bg-white w-full text-sm border rounded border-red-500 outline-[#007bff]" rows="4" required></textarea>
                        </div>



                        <!-- Submit Button -->
                        <button type="submit"
                            class="mb-10 px-5 py-2.5 rounded-full text-white text-sm tracking-wider font-medium 
                                border border-current outline-none bg-green-700 hover:bg-green-800 
                                active:bg-green-700">Hantar</button>
                    </form>
                </div>
            </div>
        </main>
    </div>


    </div>

    <script>
        const sidebar = document.getElementById('sidebar');
        const toggleBtn = document.getElementById('toggleBtn');
        const icon = toggleBtn.querySelector('i');
        const textElements = sidebar.querySelectorAll('span');
        const logoImg = document.getElementById('logoImg'); // Select elemen logo

        toggleBtn.addEventListener('click', () => {
            const isExpanded = sidebar.classList.contains('w-64');
            sidebar.classList.toggle('w-64');
            sidebar.classList.toggle('w-20');
            icon.classList.toggle('rotate-180');

            // Toggle visibility of text elements and logo
            textElements.forEach(el => {
                if (isExpanded) {
                    el.classList.add('hidden');
                } else {
                    el.classList.remove('hidden');
                }
            });

            if (isExpanded) {
                logoImg.classList.add('hidden'); // Sembunyikan logo bila sidebar tutup
            } else {
                logoImg.classList.remove('hidden'); // Tunjukkan logo bila sidebar buka
            }

            toggleBtn.setAttribute('aria-expanded', !isExpanded);
        });

        // Escape key to close sidebar
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                sidebar.classList.remove('w-64');
                sidebar.classList.add('w-20');
                icon.classList.add('rotate-180');

                textElements.forEach(el => el.classList.add('hidden'));
                logoImg.classList.add('hidden'); // Sembunyikan logo bila Escape ditekan
                toggleBtn.setAttribute('aria-expanded', 'false');
            }
        });

        // Active link detection
        document.addEventListener("DOMContentLoaded", () => {
            const currentPage = window.location.pathname.split("/").pop();
            const links = sidebar.querySelectorAll("a");

            links.forEach(link => {
                const page = link.getAttribute("data-page");
                if (page === currentPage) {
                    link.classList.add("active");
                }
            });
        });

        // Ambil button logout
        document.getElementById('logoutBtn').addEventListener('click', function() {
            // Panggil SweetAlert2 untuk pengesahan logout
            Swal.fire({
                title: 'Anda pasti?',
                text: 'Anda akan log keluar.',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Ya, Logout',
                cancelButtonText: 'Batal',
                reverseButtons: true
            }).then((result) => {
                if (result.isConfirmed) {
                    // Jika pengguna klik 'Ya, Logout', redirect ke logout.php
                    window.location.href = 'login.php';
                }
            });
        });
    </script>

</body>

</html>
