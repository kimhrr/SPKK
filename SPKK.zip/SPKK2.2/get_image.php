<?php
// get_image.php
include 'conn.php';

$response = ['success' => false, 'image_data' => '', 'image_type' => '', 'message' => 'Image not found.'];

// Check if the request_id is provided
if (isset($_GET['request_id'])) {
    $requestId = $_GET['request_id'];

    // Query the database to retrieve the image data
    $stmt = $conn->prepare("SELECT image_data, image_type FROM rekod_sakit WHERE request_id = ?");
    $stmt->bind_param("i", $requestId);
    $stmt->execute();
    $stmt->store_result();
    $stmt->bind_result($imageData, $imageType);

    if ($stmt->fetch()) {
        // Return the image data as a base64 encoded string
        $response['success'] = true;
        $response['image_data'] = base64_encode($imageData);
        $response['image_type'] = $imageType;
        $response['message'] = ''; // Clear the message if image is found
    }

    $stmt->close();
}

echo json_encode($response);
?>
