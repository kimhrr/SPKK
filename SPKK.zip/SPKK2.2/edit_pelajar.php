<?php
// edit_student.php

// Database connection
include 'conn.php';

// Check if an 'id' parameter was passed to this page
if (!isset($_GET['id'])) {
    echo "No student ID provided.";
    exit;
}

$student_id = $_GET['id'];

// Fetch student data
$sql = "SELECT * FROM pelajar WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $student_id);
$stmt->execute();
$result = $stmt->get_result();
$student = $result->fetch_assoc();

if (!$student) {
    echo "Student not found.";
    exit;
}

// Process form submission to update student details
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama = $_POST['nama'];
    $email = $_POST['email'];
    $no_ic = $_POST['no_ic'];
    $kelas = $_POST['kelas'];
    $jantina = $_POST['jantina'];

    // Update the student data in the database
    $update_sql = "UPDATE pelajar SET nama = ?, email = ?, no_ic = ?, kelas = ?, jantina = ? WHERE id = ?";
    $update_stmt = $conn->prepare($update_sql);
    $update_stmt->bind_param("sssssi", $nama, $email, $no_ic, $kelas, $jantina, $student_id);

    if ($update_stmt->execute()) {
        echo "<script>alert('Student details updated successfully'); window.location.href = 'super_list.php';</script>";
    } else {
        echo "Error updating student details: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Student</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100 flex items-center justify-center h-screen">

<div class="bg-white p-8 rounded-lg shadow-md w-full max-w-md">
    <h2 class="text-2xl font-semibold text-gray-800 mb-6">Edit Student Details</h2>
    
    <form method="POST" action="">
        <div class="mb-4">
            <label for="nama" class="block text-gray-700 font-medium mb-2">Name:</label>
            <input type="text" id="nama" name="nama" value="<?= htmlspecialchars($student['nama']) ?>" required
                   class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
        </div>

        <div class="mb-4">
            <label for="email" class="block text-gray-700 font-medium mb-2">Email:</label>
            <input type="email" id="email" name="email" value="<?= htmlspecialchars($student['email']) ?>" required
                   class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
        </div>

        <div class="mb-4">
            <label for="no_ic" class="block text-gray-700 font-medium mb-2">IC Number:</label>
            <input type="text" id="no_ic" name="no_ic" value="<?= htmlspecialchars($student['no_ic']) ?>" required
                   class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
        </div>

        <div class="mb-4">
            <label for="kelas" class="block text-gray-700 font-medium mb-2">Class:</label>
            <input type="text" id="kelas" name="kelas" value="<?= htmlspecialchars($student['kelas']) ?>" required
                   class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
        </div>

        <div class="mb-6">
            <label for="jantina" class="block text-gray-700 font-medium mb-2">Gender:</label>
            <select id="jantina" name="jantina" required
                    class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                <option value="Lelaki" <?= $student['jantina'] == 'Lelaki' ? 'selected' : '' ?>>Lelaki</option>
                <option value="Perempuan" <?= $student['jantina'] == 'Perempuan' ? 'selected' : '' ?>>Perempuan</option>
            </select>
        </div>

        <button type="submit" class="w-full bg-blue-500 text-white font-medium py-2 rounded-lg hover:bg-blue-600 transition duration-200">
            Update
        </button>
    </form>
</div>

</body>
</html>

<?php
$conn->close();
?>
