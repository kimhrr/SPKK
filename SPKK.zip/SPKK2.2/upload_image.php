<?php
// upload_image.php
include 'conn.php';

$response = ['success' => false, 'message' => ''];

if (isset($_FILES['image']) && isset($_POST['request_id'])) {
    $requestId = $_POST['request_id'];
    $imageData = file_get_contents($_FILES['image']['tmp_name']);
    $imageType = $_FILES['image']['type'];

    // Check if record already exists for the given request_id
    $stmt = $conn->prepare("SELECT * FROM rekod_sakit WHERE request_id = ?");
    $stmt->bind_param("i", $requestId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Update the existing record with the new image
        $updateStmt = $conn->prepare("UPDATE rekod_sakit SET image_data = ?, image_type = ? WHERE request_id = ?");
        $updateStmt->bind_param("ssi", $imageData, $imageType, $requestId);
        if ($updateStmt->execute()) {
            $response['success'] = true;
        } else {
            $response['message'] = 'Failed to update image: ' . $updateStmt->error;
        }
        $updateStmt->close();
    } else {
        // Insert a new record if none exists
        $insertStmt = $conn->prepare("INSERT INTO rekod_sakit (request_id, image_data, image_type) VALUES (?, ?, ?)");
        $insertStmt->bind_param("iss", $requestId, $imageData, $imageType);
        if ($insertStmt->execute()) {
            $response['success'] = true;
        } else {
            $response['message'] = 'Failed to insert image: ' . $insertStmt->error;
        }
        $insertStmt->close();
    }

    $stmt->close();
}

echo json_encode($response);
?>
