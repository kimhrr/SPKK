<?php
// Start the session (if necessary)
session_start();

// Fetch user data from the session
$user_id = $_SESSION['id'];

// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the form data
    $tarikh = $_POST['date_field'];
    $sebab = $_POST['textarea_field'];
    $status = 'Pending';

    // Ensure the date format is valid (YYYY-MM-DD)
    $date = DateTime::createFromFormat('Y-m-d', $tarikh);
    if ($date && $date->format('Y-m-d') === $tarikh) {
        // Valid date format
        $tarikh = $date->format('Y-m-d'); // Ensure it is in the correct format
    } else {
        die("Invalid date format. Please use YYYY-MM-DD.");
    }

    // Connect to the database
    include 'conn.php'; // Make sure to set up your database connection in this file

    // Prepare the SQL query to insert the data
    $query = "INSERT INTO pelajar_req (id, sebab, tarikh, status) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($query);

    if ($stmt === false) {
        die("Error preparing statement: " . $conn->error);
    }

    // Bind the parameters to the query (date and textarea values)
    $stmt->bind_param('isss', $user_id, $sebab, $tarikh, $status);

    // Execute the query
    if ($stmt->execute()) {
        header("Location: permohonan.php");
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
}
?>
