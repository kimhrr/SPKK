<?php
// Start the session
session_start();

// Fetch user data from the session
$user_id = $_SESSION['id'];

// Connect to the database
include 'conn.php';

// Prepare the SQL query to fetch student details from the pelajar table
$studentQuery = 'SELECT nama, kelas, email FROM pelajar WHERE id = ?';
$studentStmt = $conn->prepare($studentQuery);

if ($studentStmt === false) {
    die('Error preparing student statement: ' . $conn->error);
}

// Bind the user_id to the query for student details
$studentStmt->bind_param('i', $user_id);

// Execute the query for student details
$studentStmt->execute();

// Get the result for student details
$studentResult = $studentStmt->get_result();
$studentData = $studentResult->fetch_assoc(); // Fetch a single row

// Close the statement for student details
$studentStmt->close();

// Prepare the SQL query to fetch records from the pelajar_req table
$requestQuery = 'SELECT * FROM pelajar_req WHERE id = ?';
$requestStmt = $conn->prepare($requestQuery);

if ($requestStmt === false) {
    die('Error preparing request statement: ' . $conn->error);
}

// Bind the user_id to the query for requests
$requestStmt->bind_param('i', $user_id);

// Execute the query for requests
$requestStmt->execute();

// Get the result for requests
$requestResult = $requestStmt->get_result();

if ($requestResult->num_rows > 0) {
    $records = $requestResult->fetch_all(MYSQLI_ASSOC);
} else {
    $records = [];
}

// Close the statement and connection for requests
$requestStmt->close();
$conn->close();
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SPKK | Permohonan</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100;300;400;500;700;900&display=swap"
        rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        body {
            font-family: 'Montserrat', sans-serif;
        }
    </style>
</head>

<body class="bg-[#F0FFFF] flex-auto">
    <div class="min-h-screen flex">
        <!-- Sidebar -->
        <aside id="sidebar"
            class="bg-white shadow-2xl transition-all duration-300 ease-in-out w-64 border-r border-gray-200"
            aria-label="Sidebar" role="navigation">
            <div class="h-full px-6 py-5 flex flex-col">
                <div class="flex items-center justify-between mb-8">
                    <div class="flex items-center gap-3">
                        <img id="logoImg" src="img/logo-spkk.png" alt="Logo"
                            class="h-30 w-auto transition-opacity duration-300">
                    </div>
                    <button id="toggleBtn"
                        class="p-2 rounded-lg hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        aria-label="Toggle Sidebar" aria-expanded="true">
                        <i class="fas fa-chevron-left transition-transform duration-300"></i>
                    </button>
                </div>

                <nav class="space-y-3 flex-grow">
                    <a href="home_page.php"
                        class="flex items-center p-3 text-gray-700 rounded-lg hover:bg-blue-50 group transition-colors hover:text-blue-600"
                        data-page="home_page.php">
                        <i class="fas fa-home w-6 h-6"></i>
                        <span class="ml-3 font-medium transition-opacity duration-300">Home</span>
                    </a>
                    <a href="permohonan.php"
                        class="flex items-center p-3 text-gray-700 rounded-lg hover:bg-blue-50 group transition-colors hover:text-blue-600"
                        data-page="permohonan.php">
                        <i class="fa-regular fa-pen-to-square w-6 h-6"></i>
                        <span class="ml-3 font-medium transition-opacity duration-300">Permohonan</span>
                    </a>
                    <a href="rekod_sakit.php"
                        class="flex items-center p-3 text-gray-700 rounded-lg hover:bg-blue-50 group transition-colors hover:text-blue-600"
                        data-page="sijil_sakit.php">
                        <i class="fa-solid fa-file-medical w-6 h-6"></i>
                        <span class="ml-3 font-medium transition-opacity duration-300">Rekod Sakit</span>
                    </a>
                    <a href="Pensyarah_bertugas.php"
                        class="flex items-center p-3 text-gray-700 rounded-lg hover:bg-blue-50 group transition-colors hover:text-blue-600"
                        data-page="Pensyarah_bertugas.php">
                        <i class="fas fa-users w-6 h-6"></i>
                        <span class="ml-3 font-medium transition-opacity duration-300">Pensyarah Bertugas</span>
                    </a>
                </nav>

                <div class="mt-auto border-t pt-4 space-y-4">
                    <a href="javascript:void(0);" id="logoutBtn"
                        class="flex items-center p-3 text-red-600 rounded-lg hover:bg-red-50 group transition-colors">
                        <i class="fas fa-sign-out-alt w-6 h-6"></i>
                        <span class="ml-3 font-medium transition-opacity duration-300">Logout</span>
                    </a>
                </div>
            </div>
        </aside>

        <!-- Main Content -->
        <main class="flex-1 p-8">
            <header class="flex border-b border-black sm:px-0 bg-[#F0FFFF] min-h-[40px] tracking-wide relative z-80">
                <div class="flex flex-wrap items-center gap-5 w-full">
                    <a href="javascript:void(0)" class="text-1xl">SPKK-KV KUALA SELANGOR</a>
                </div>
                <button id="toggleSidebar" class="lg:hidden ml-auto p-2">
                    <svg class="w-7 h-7" fill="#000" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                        <path fill-rule="evenodd"
                            d="M3 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 10a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 15a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z"
                            clip-rule="evenodd"></path>
                    </svg>
                </button>
            </header>

            <!-- Section Content -->
            <section class="mt-9 max-w-1xl mx-auto main-content" id="mainContent">
                <p class="text-1xl font-semibold">PERMOHONAN</p>
                <br>




                <!-- Maklumat Pelajar -->
                <div class="bg-gray-200 rounded-md p-4 mb-6 mx-mt">
                    <div class="header-borang font-semibold bg-[#216565] rounded-md py-3 mb-4">
                        <h3 class="ml-3 text-white">Maklumat Pelajar</h3>
                    </div>
                    <div class="grid grid-cols-4 gap-2 px-6">
                        <!-- Nama -->
                        <div class="bg-[#008080] text-white px-3 py-2 rounded-lg font-medium text-sm col-span-1">Nama
                        </div>
                        <div class="bg-[white] text-black px-3 py-2 rounded-lg text-sm col-span-3 text-left">
                            <?= htmlspecialchars($studentData['nama']) ?>
                        </div>

                        <!-- Kelas -->
                        <div class="bg-[#008080] text-white px-3 py-2 rounded-lg font-medium text-sm col-span-1">Kelas
                        </div>
                        <div class="bg-[white] text-black px-3 py-2 rounded-lg text-sm col-span-3 text-left">
                            <?= htmlspecialchars($studentData['kelas']) ?>
                        </div>

                        <!-- Email Moe -->
                        <div class="bg-[#008080] text-white px-3 py-2 rounded-lg font-medium text-sm col-span-1">Email
                            Moe</div>
                        <div class="bg-[white] text-black px-3 py-2 rounded-lg text-sm col-span-3 text-left">
                            <?= htmlspecialchars($studentData['email']) ?>
                        </div>
                    </div>
                </div>



                <!-- Info Box -->

                <div class="font-[sans-serif] space-y-6">
                    <div class="flex items-start max-sm:flex-col bg-blue-100 text-blue-800 p-4 rounded-lg relative mb-5"
                        role="alert">
                        <div class="flex items-center max-sm:mb-2">
                            <svg xmlns="http://www.w3.org/2000/svg" class="w-[18px] fill-blue-500 inline mr-3"
                                viewBox="0 0 23.625 23.625">
                                <path
                                    d="M11.812 0C5.289 0 0 5.289 0 11.812s5.289 11.813 11.812 11.813 11.813-5.29 11.813-11.813S18.335 0 11.812 0zm2.459 18.307c-.608.24-1.092.422-1.455.548a3.838 3.838 0 0 1-1.262.189c-.736 0-1.309-.18-1.717-.539s-.611-.814-.611-1.367c0-.215.015-.435.045-.659a8.23 8.23 0 0 1 .147-.759l.761-2.688c.067-.258.125-.503.171-.731.046-.23.068-.441.068-.633 0-.342-.071-.582-.212-.717-.143-.135-.412-.201-.813-.201-.196 0-.398.029-.605.09-.205.063-.383.12-.529.176l.201-.828c.498-.203.975-.377 1.43-.521a4.225 4.225 0 0 1 1.29-.218c.731 0 1.295.178 1.692.53.395.353.594.812.594 1.376 0 .117-.014.323-.041.617a4.129 4.129 0 0 1-.152.811l-.757 2.68a7.582 7.582 0 0 0-.167.736 3.892 3.892 0 0 0-.073.626c0 .356.079.599.239.728.158.129.435.194.827.194.185 0 .392-.033.626-.097.232-.064.4-.121.506-.17l-.203.827zm-.134-10.878a1.807 1.807 0 0 1-1.275.492c-.496 0-.924-.164-1.28-.492a1.57 1.57 0 0 1-.533-1.193c0-.465.18-.865.533-1.196a1.812 1.812 0 0 1 1.28-.497c.497 0 .923.165 1.275.497.353.331.53.731.53 1.196 0 .467-.177.865-.53 1.193z"
                                    data-original="#030104" />
                            </svg>
                            <strong class="font-bold text-sm">Perhatian!</strong>
                        </div>

                        <span class="block sm:inline text-sm ml-4 mr-8 max-sm:ml-0 max-sm:mt-2">Sila Tunggu Seketika
                            Permohonan , Anda Sedang Disemak</span>

                        <svg xmlns="http://www.w3.org/2000/svg"
                            class="w-7 hover:bg-blue-200 rounded-lg transition-all p-2 cursor-pointer fill-blue-500 absolute right-4 top-1/2 -translate-y-1/2"
                            viewBox="0 0 320.591 320.591">
                        </svg>
                    </div>

                </div>

                <!-- Table Rekod Pemohonan -->
                <div class="bg-gray-300 rounded-md p-6 border border-gray-400">
                    <table class="w-full text-left border-collapse border border-gray-400">
                        <thead>
                            <tr class="bg-[#008080] text-white text-sm">
                                <th class="p-2 font-medium border border-gray-400">Bil</th>
                                <th class="p-3 font-medium border border-gray-400">Sebab Ingin Ke Klinik</th>
                                <th class="p-3 font-medium border border-gray-400">Tarikh Pemohonan</th>
                                <th class="p-2 font-medium border border-gray-400">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($records) > 0): ?>
                            <?php foreach ($records as $index => $record): ?>
                            <?php
                            // Tentukan class berdasarkan status
                            $statusClass = '';
                            $statusTextClass = ''; // Class untuk warna teks
                            switch (strtolower($record['status'])) {
                                case 'pending':
                                    $statusClass = ''; // Kuning latar belakang
                                    $statusTextClass = 'text-yellow-600'; // Kuning teks
                                    break;
                                case 'terima':
                                    $statusClass = ''; // Hijau latar belakang
                                    $statusTextClass = 'text-green-700'; // Hijau teks
                                    break;
                                case 'ditolak':
                                    $statusClass = ''; // Merah latar belakang
                                    $statusTextClass = 'text-red-700'; // Merah teks
                                    break;
                                default:
                                    $statusClass = ''; // Default latar belakang
                                    $statusTextClass = 'text-gray-600'; // Default teks
                                    break;
                            }
                            ?>
                            <tr class="text-gray-700 bg-gray-200 text-sm">
                                <td class="p-2 border border-gray-400"><?= $index + 1 ?></td>
                                <td class="p-3 border border-gray-400"><?= htmlspecialchars($record['sebab']) ?></td>
                                <td class="p-3 border border-gray-400"><?= htmlspecialchars($record['tarikh']) ?></td>
                                <td class="p-2 border border-gray-400 <?= $statusClass ?> <?= $statusTextClass ?>">
                                    <?= htmlspecialchars($record['status']) ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php else: ?>
                            <tr class="text-gray-700 bg-gray-200 text-sm">
                                <td colspan="4" class="p-2 text-center border border-gray-400">Tiada Rekod
                                    Pemohonan ..</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>


                <!-- Scripts -->
                <script>
                    const sidebar = document.getElementById('sidebar');
                    const toggleBtn = document.getElementById('toggleBtn');
                    const icon = toggleBtn.querySelector('i');
                    const textElements = sidebar.querySelectorAll('span');
                    const logoImg = document.getElementById('logoImg'); // Select elemen logo

                    toggleBtn.addEventListener('click', () => {
                        const isExpanded = sidebar.classList.contains('w-64');
                        sidebar.classList.toggle('w-64');
                        sidebar.classList.toggle('w-20');
                        icon.classList.toggle('rotate-180');

                        // Toggle visibility of text elements and logo
                        textElements.forEach(el => {
                            if (isExpanded) {
                                el.classList.add('hidden');
                            } else {
                                el.classList.remove('hidden');
                            }
                        });

                        if (isExpanded) {
                            logoImg.classList.add('hidden'); // Sembunyikan logo bila sidebar tutup
                        } else {
                            logoImg.classList.remove('hidden'); // Tunjukkan logo bila sidebar buka
                        }

                        toggleBtn.setAttribute('aria-expanded', !isExpanded);
                    });

                    // Escape key to close sidebar
                    document.addEventListener('keydown', (e) => {
                        if (e.key === 'Escape') {
                            sidebar.classList.remove('w-64');
                            sidebar.classList.add('w-20');
                            icon.classList.add('rotate-180');

                            textElements.forEach(el => el.classList.add('hidden'));
                            logoImg.classList.add('hidden'); // Sembunyikan logo bila Escape ditekan
                            toggleBtn.setAttribute('aria-expanded', 'false');
                        }
                    });

                    // Ambil button logout
                    document.getElementById('logoutBtn').addEventListener('click', function() {
                        // Panggil SweetAlert2 untuk pengesahan logout
                        Swal.fire({
                            title: 'Anda pasti?',
                            text: 'Anda akan log keluar.',
                            icon: 'warning',
                            showCancelButton: true,
                            confirmButtonText: 'Ya, Logout',
                            cancelButtonText: 'Batal',
                            reverseButtons: true
                        }).then((result) => {
                            if (result.isConfirmed) {
                                // Jika pengguna klik 'Ya, Logout', redirect ke logout.php
                                window.location.href = 'login.php';
                            }
                        });
                    });
                </script>


</body>

</html>
