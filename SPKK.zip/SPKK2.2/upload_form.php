<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Upload Image</title>
</head>
<body>
    <form action="upload_process.php" method="post" enctype="multipart/form-data">
        <label for="image">Choose an image:</label>
        <input type="file" name="image" id="image" required>
        <button type="submit">Upload Image</button>
    </form>

    <!-- Replace '1' with the actual ID of the image you want to display -->
    <img src="display_image.php?id=3" alt="Image">

</body>
</html>

