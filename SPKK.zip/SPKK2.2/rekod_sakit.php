<?php
session_start();

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if the user is logged in
if (!isset($_SESSION['id']) || $_SESSION['role'] != 'Pelajar') {
    // Redirect to login page if not logged in
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['id'];

// Connect to the Database
include 'conn.php';

// Query to join tables and retrieve data
$sql = "
SELECT pelajar.id AS id, pelajar.nama AS nama, pelajar.kelas AS kelas,
       request_status.tarikh, request_status.sebab,
       request_status.status, request_status.request_id AS request_id
FROM pelajar
JOIN request_status ON pelajar.id = request_status.id
JOIN rekod_sakit ON request_status.request_id = rekod_sakit.request_id
WHERE pelajar.id = '$user_id'";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SPKK | Rekod Sakit</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100;300;400;500;700;900&display=swap"
        rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.tailwindcss.com"></script>

    <style>
        body {
            font-family: 'Montserrat', sans-serif;
        }

        .active {
            background-color: #ebf8ff;
            color: #ebf8ff;
        }
    </style>
</head>

<body class="bg-[#F0FFFF] flex-auto">
    <div class="min-h-screen flex">
        <!-- Sidebar -->
        <aside id="sidebar"
            class="bg-white shadow-2xl transition-all duration-300 ease-in-out w-64 border-r border-gray-200"
            aria-label="Sidebar" role="navigation">
            <div class="h-full px-6 py-5 flex flex-col">
                <div class="flex items-center justify-between mb-8">
                    <div class="flex items-center gap-3">
                        <img id="logoImg" src="img/logo-spkk.png" alt="Logo"
                            class="h-30 w-auto transition-opacity duration-300">
                    </div>
                    <button id="toggleBtn"
                        class="p-2 rounded-lg hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        aria-label="Toggle Sidebar" aria-expanded="true">
                        <i class="fas fa-chevron-left transition-transform duration-300"></i>
                    </button>
                </div>

                <nav class="space-y-3 flex-grow">
                    <a href="home_page.php"
                        class="flex items-center p-3 text-gray-700 rounded-lg hover:bg-blue-50 group transition-colors hover:text-blue-600"
                        data-page="home_page.php">
                        <i class="fas fa-home w-6 h-6"></i>
                        <span class="ml-3 font-medium transition-opacity duration-300">Home</span>
                    </a>
                    <a href="permohonan.php"
                        class="flex items-center p-3 text-gray-700 rounded-lg hover:bg-blue-50 group transition-colors hover:text-blue-600"
                        data-page="permohonan.php">
                        <i class="fa-regular fa-pen-to-square w-6 h-6"></i>
                        <span class="ml-3 font-medium transition-opacity duration-300">Permohonan</span>
                    </a>
                    <a href="rekod_sakit.php"
                        class="flex items-center p-3 text-gray-700 rounded-lg hover:bg-blue-50 group transition-colors hover:text-blue-600"
                        data-page="sijil_sakit.php">
                        <i class="fa-solid fa-file-medical w-6 h-6"></i>
                        <span class="ml-3 font-medium transition-opacity duration-300">Rekod Sakit</span>
                    </a>
                    <a href="Pensyarah_bertugas.php"
                        class="flex items-center p-3 text-gray-700 rounded-lg hover:bg-blue-50 group transition-colors hover:text-blue-600"
                        data-page="Pensyarah_bertugas.php">
                        <i class="fas fa-users w-6 h-6"></i>
                        <span class="ml-3 font-medium transition-opacity duration-300">Pensyarah Bertugas</span>
                    </a>
                </nav>

                <div class="mt-auto border-t pt-4 space-y-4">
                    <a href="javascript:void(0);" id="logoutBtn"
                        class="flex items-center p-3 text-red-600 rounded-lg hover:bg-red-50 group transition-colors">
                        <i class="fas fa-sign-out-alt w-6 h-6"></i>
                        <span class="ml-3 font-medium transition-opacity duration-300">Logout</span>
                    </a>
                </div>
            </div>
        </aside>

        <!-- Main Content -->
        <main class="flex-1 p-8">
            <header class="flex border-b border-black sm:px-0 bg-[#F0FFFF] min-h-[40px] tracking-wide relative">
                <div class="flex flex-wrap items-center gap-5 w-full">
                    <a href="javascript:void(0)" class="text-1xl">SPKK-KV KUALA SELANGOR</a>
                </div>
                <button id="toggleSidebar" class="lg:hidden ml-auto p-2">
                    <svg class="w-7 h-7" fill="#000" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                        <path fill-rule="evenodd"
                            d="M3 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 10a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 15a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z"
                            clip-rule="evenodd"></path>
                    </svg>
                </button>
            </header>

            <div class="container mx-auto p-4">
                <h2 class="borang font-semibold mb-2">
                    REKOD SAKIT
                </h2>
                <div class="overflow-x-auto bg-white shadow-md rounded-lg">
                    <table class="min-w-full bg-white border border-gray-200">
                        <thead class="bg-[#008080]">
                            <tr>
                                <th class="py-3 px-6 text-left text-white border uppercase font-semibold text-sm">Bil</th>
                                <th class="py-3 px-6 text-left text-white border uppercase font-semibold text-sm">Pelajar
                                </th>
                                <th class="py-3 px-6 text-left text-white border uppercase font-semibold text-sm">Kelas</th>
                                <th class="py-3 px-6 text-left text-white border uppercase font-semibold text-sm">Tarikh
                                </th>
                                <th class="py-3 px-6 text-left text-white border uppercase font-semibold text-sm">Sebab</th>
                                <th class="py-3 px-6 text-center text-white border uppercase font-semibold text-sm">Status
                                </th>
                                <th class="py-3 px-6 text-center text-white border uppercase font-semibold text-sm">Tindakan
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $bil = 1;
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    echo "<tr class='border-b border-gray-200 bg-gray-50 text-sm'>";
                                    echo "<td class='py-3 px-6 text-gray-800'>" . htmlspecialchars($bil++) . '</td>';
                                    echo "<td class='py-3 px-6 text-gray-800'>" . htmlspecialchars($row['nama']) . '</td>';
                                    echo "<td class='py-3 px-6 text-gray-800'>" . htmlspecialchars($row['kelas']) . '</td>';
                                    echo "<td class='py-3 px-6 text-gray-800'>" . htmlspecialchars($row['tarikh']) . '</td>';
                                    echo "<td class='py-3 px-6 text-gray-800'>" . htmlspecialchars($row['sebab']) . '</td>';
                                    echo "<td class='py-3 px-6 text-center text-gray-800'>" . htmlspecialchars($row['status']) . '</td>';
                                    echo "<td class='py-3 px-6 text-center flex justify-center gap-2'>";
                                    echo "<button class='bg-blue-500 text-white px-4 py-1 rounded hover:bg-blue-600 show-image' data-request-id='" . $row['request_id'] . "'><i class='fas fa-eye'></i></button>";
                                    echo '</td>';
                                    echo '</tr>';
                                }
                            } else {
                                echo "<tr><td colspan='7' class='text-center py-4'>Tiada rekod dijumpai.</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>

    <script>
        const sidebar = document.getElementById('sidebar');
        const toggleBtn = document.getElementById('toggleBtn');
        const icon = toggleBtn.querySelector('i');
        const textElements = sidebar.querySelectorAll('span');
        const logoImg = document.getElementById('logoImg'); // Select elemen logo

        toggleBtn.addEventListener('click', () => {
            const isExpanded = sidebar.classList.contains('w-64');
            sidebar.classList.toggle('w-64');
            sidebar.classList.toggle('w-20');
            icon.classList.toggle('rotate-180');

            // Toggle visibility of text elements and logo
            textElements.forEach(el => {
                if (isExpanded) {
                    el.classList.add('hidden');
                } else {
                    el.classList.remove('hidden');
                }
            });

            if (isExpanded) {
                logoImg.classList.add('hidden'); // Sembunyikan logo bila sidebar tutup
            } else {
                logoImg.classList.remove('hidden'); // Tunjukkan logo bila sidebar buka
            }

            toggleBtn.setAttribute('aria-expanded', !isExpanded);
        });

        // Escape key to close sidebar
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                sidebar.classList.remove('w-64');
                sidebar.classList.add('w-20');
                icon.classList.add('rotate-180');

                textElements.forEach(el => el.classList.add('hidden'));
                logoImg.classList.add('hidden'); // Sembunyikan logo bila Escape ditekan
                toggleBtn.setAttribute('aria-expanded', 'false');
            }
        });

        function uploadImagePopup(requestId) {
            Swal.fire({
                title: 'Muat Naik Gambar',
                html: `
            <form id="imageUploadForm" enctype="multipart/form-data">
                <input type="file" id="imageInput" name="image" accept="image/*" class="swal2-input" style="width: auto;" required>
                <input type="hidden" name="request_id" value="${requestId}">
            </form>
        `,
                showCancelButton: true,
                confirmButtonText: 'Upload',
                preConfirm: () => {
                    const form = document.getElementById('imageUploadForm');
                    const formData = new FormData(form);

                    return fetch('upload_image.php', {
                            method: 'POST',
                            body: formData
                        })
                        .then(response => response.json())
                        .then(data => {
                            if (!data.success) {
                                throw new Error(data.message || 'Failed to upload image');
                            }
                            return data;
                        })
                        .catch(error => {
                            Swal.showValidationMessage(`Request failed: ${error}`);
                        });
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    Swal.fire('Success!', 'Image uploaded successfully', 'success');
                }
            });
        }

        // Handle the "Show Image" button click
        document.addEventListener('DOMContentLoaded', function() {
            const buttons = document.querySelectorAll('.show-image');

            buttons.forEach(button => {
                button.addEventListener('click', function() {
                    const requestId = this.getAttribute('data-request-id');

                    // Send AJAX request to get the image
                    fetch(`get_image.php?request_id=${requestId}`)
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                // Display the image using SweetAlert
                                Swal.fire({
                                    title: 'Image',
                                    imageUrl: 'data:' + data.image_type + ';base64,' +
                                        data.image_data,
                                    imageAlt: 'Uploaded Image',
                                    showCloseButton: true
                                });
                            } else {
                                // Show error if image is not found
                                Swal.fire('Error', data.message, 'error');
                            }
                        })
                        .catch(error => {
                            Swal.fire('Error', 'Failed to load image', 'error');
                        });
                });
            });
        });

        // Ambil button logout
        document.getElementById('logoutBtn').addEventListener('click', function() {
            // Panggil SweetAlert2 untuk pengesahan logout
            Swal.fire({
                title: 'Anda pasti?',
                text: 'Anda akan log keluar.',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Ya, Logout',
                cancelButtonText: 'Batal',
                reverseButtons: true
            }).then((result) => {
                if (result.isConfirmed) {
                    // Jika pengguna klik 'Ya, Logout', redirect ke logout.php
                    window.location.href = 'login.php';
                }
            });
        });
    </script>
</body>

</html>
