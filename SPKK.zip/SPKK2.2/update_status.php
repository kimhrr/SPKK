<?php
session_start();
include 'conn.php';

header('Content-Type: application/json');

// Capture the data from the frontend
$data = json_decode(file_get_contents("php://input"), true);
$request_id = $data['id'];  // 'id' is sent from frontend
$status = $data['status'];

// Start a transaction to ensure data consistency
$conn->begin_transaction();

try {
    // Step 1: Get the current status from pelajar_req table
    $query = "SELECT id, sebab, tarikh, status FROM pelajar_req WHERE request_id = ?";
    $stmt = $conn->prepare($query);
    if (!$stmt) {
        throw new Exception("Error preparing statement: " . $conn->error);
    }
    $stmt->bind_param("i", $request_id);
    $stmt->execute();
    $stmt->bind_result($id, $sebab, $tarikh, $current_status);
    $stmt->fetch();
    $stmt->close();

    // Check if the status is 'Pending'
    if ($current_status === 'Pending') {
        // Step 2: Update the status in pelajar_req table
        $query = "UPDATE pelajar_req SET status = ? WHERE request_id = ?";
        $stmt = $conn->prepare($query);
        if (!$stmt) {
            throw new Exception("Error preparing statement: " . $conn->error);
        }
        $stmt->bind_param("si", $status, $request_id);
        $stmt->execute();
        if ($stmt->affected_rows === 0) {
            throw new Exception("Error: No rows updated.");
        }
        $stmt->close();

        if ($status === 'Terima') {
            // Step 3: Insert the status change into the request_status table
            $query = "INSERT INTO request_status (request_id, id, sebab, tarikh, status) VALUES (?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($query);
            if (!$stmt) {
                throw new Exception("Error preparing statement: " . $conn->error);
            }
            $stmt->bind_param("iisss", $request_id, $id, $sebab, $tarikh, $status);
            $stmt->execute();
            if ($stmt->affected_rows === 0) {
                throw new Exception("Error: No rows inserted into request_status.");
            }
            $stmt->close();

            // Step 3: Insert the status change into the request_status table
            $query = "INSERT INTO rekod_sakit (request_id, id) VALUES (?, ?)";
            $stmt = $conn->prepare($query);
            if (!$stmt) {
                throw new Exception("Error preparing statement: " . $conn->error);
            }
            $stmt->bind_param("ii", $request_id, $id);
            $stmt->execute();
            if ($stmt->affected_rows === 0) {
                throw new Exception("Error: No rows inserted into request_status.");
            }
            $stmt->close();

        }   else {

            // Step 3: Insert the status change into the request_status table
            $query = "INSERT INTO request_status (request_id, id, sebab, tarikh, status) VALUES (?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($query);
            if (!$stmt) {
                throw new Exception("Error preparing statement: " . $conn->error);
            }
            $stmt->bind_param("iisss", $request_id, $id, $sebab, $tarikh, $status);
            $stmt->execute();
            if ($stmt->affected_rows === 0) {
                throw new Exception("Error: No rows inserted into request_status.");
            }
            $stmt->close();

        }   

        // Commit the transaction
        $conn->commit();

        echo json_encode(["success" => true]);
    } else {
        throw new Exception("Status is not pending, cannot update.");
    }
} catch (Exception $e) {
    // Rollback the transaction if any error occurs
    $conn->rollback();
    echo json_encode(["success" => false, "error" => $e->getMessage()]);
}

$conn->close();
?>
