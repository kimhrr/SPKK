<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <title>SPKK | Daftar Akaun</title>
    <style>
        /* Global Styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            height: 100vh;
            background: linear-gradient(135deg, white 50%, #7db3ff 50%);
        }
    </style>
</head>

<body>
    <div class="flex flex-col justify-center font-[sans-serif] sm:h-screen p-4">
        <div class="max-w-md w-full mx-auto border border-gray-300 rounded-2xl p-8 bg-slate-100">
            <div class="text-center mb-12">
                <h2 class="text-gray-800 text-center text-2xl font-bold">Daftar Akaun</h2>
            </div>

            <!-- Code PHP Function Register -->
            <?php
            $message = '';
            
            $servername = 'localhost';
            $username = 'root';
            $password = '';
            $dbname = 'spkk';
            
            $conn = new mysqli($servername, $username, $password, $dbname);
            
            if ($conn->connect_error) {
                die('Connection failed: ' . $conn->connect_error);
            }
            
            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                $email = $_POST['email'];
                $password = $_POST['password'];
                $cpassword = $_POST['cpassword'];
                $nama = $_POST['nama'];
                $kelas = $_POST['kelas'];
                $role = $_POST['role'];
            
                if ($password !== $cpassword) {
                    $message = 'Passwords do not match!';
                } else {
                    $email_check = $conn->prepare('SELECT id FROM user WHERE email = ?');
                    $email_check->bind_param('s', $email);
                    $email_check->execute();
                    $result = $email_check->get_result();
            
                    if ($result->num_rows > 0) {
                        $message = 'Email already registered!';
                    } else {
                        $hashed_password = password_hash($password, PASSWORD_BCRYPT);
                        $conn->begin_transaction();
            
                        try {
                            $sql_user = 'INSERT INTO user (email, pass, role) VALUES (?, ?, ?)';
                            $stmt_user = $conn->prepare($sql_user);
                            $stmt_user->bind_param('sss', $email, $hashed_password, $role);
                            $stmt_user->execute();
            
                            $user_id = $conn->insert_id;
            
                            if ($role == 'Pelajar') {
                                $sql_pelajar = 'INSERT INTO pelajar (id, nama, email, kelas) VALUES (?, ?, ?, ?)';
                                $stmt_pelajar = $conn->prepare($sql_pelajar);
                                $stmt_pelajar->bind_param('isss', $user_id, $nama, $email, $kelas);
                                $stmt_pelajar->execute();
                            } elseif ($role == 'Pensyarah') {
                                $sql_pensyarah = 'INSERT INTO pensyarah (id, nama) VALUES (?, ?)';
                                $stmt_pensyarah = $conn->prepare($sql_pensyarah);
                                $stmt_pensyarah->bind_param('is', $user_id, $nama);
                                $stmt_pensyarah->execute();
                            }
            
                            $conn->commit();
                            $message = 'Account successfully registered!';
                        } catch (Exception $e) {
                            $conn->rollback();
                            $message = 'Error: ' . $e->getMessage();
                        }
                    }
                }
            }
            $conn->close();
            ?>

            <?php if ($message): ?>
            <p class="text-center text-green-500 mb-4"><?= htmlspecialchars($message) ?></p>
            <?php endif; ?>

            <form method="POST">
                <div class="space-y-6">
                    <div>
                        <label class="text-gray-800 text-sm mb-2 block">Nama</label>
                        <input name="nama" type="text"
                            class="text-gray-800 bg-white border border-gray-300 w-full text-sm px-4 py-3 rounded-md outline-blue-500 uppercase"
                            placeholder="Masukkan Nama Penuh" required />
                    </div>
                    <div>
                        <label class="text-gray-800 text-sm mb-2 block">Kursus</label>
                        <select name="kelas"
                            class="text-gray-800 bg-white border border-gray-300 w-full text-sm px-4 py-3 rounded-md outline-blue-500"
                            required>
                            <option value="" disabled selected>Pilih Kursus Anda</option>
                            <option value="KPD">KPD</option>
                            <option value="KMK">KMK</option>
                            <option value="HSK">HSK</option>
                            <option value="HBP">HBP</option>
                            <option value="BAK">BAK </option>
                            <option value="BPM">BPM </option>
                            <option value="OPP">OPP</option>
                        </select>
                    </div>
                    <div>
                        <label class="text-gray-800 text-sm mb-2 block">Email</label>
                        <input name="email" type="email"
                            class="text-gray-800 bg-white border border-gray-300 w-full text-sm px-4 py-3 rounded-md outline-blue-500"
                            placeholder="Masukkan Email" required />
                    </div>
                    <div>
                        <label class="text-gray-600 text-sm font-medium block">Kata Laluan</label>
                        <div class="relative">
                            <input name="password" type="password" required
                                class="w-full mt-2 text-gray-800 text-sm border border-gray-300 px-4 py-3 rounded-lg outline-none focus:ring-2 focus:ring-blue-500"
                                placeholder="Masukkan Kata Laluan" id="passwordInput" />
                            <button type="button" onclick="togglePassword()"
                                class="absolute right-3 top-3 text-gray-500 hover:text-gray-700 focus:outline-none mt-2">
                                <i id="eyeIcon" class="fas fa-eye"></i>
                            </button>
                        </div>
                    </div>

                    <label class="text-gray-600 text-sm font-medium block">Pengesahan Kata Laluan</label>
                    <div class="relative">
                        <input name="cpassword" type="password" required
                            class="w-full mt-2 text-gray-800 text-sm border border-gray-300 px-4 py-3 rounded-lg outline-none focus:ring-2 focus:ring-blue-500"
                            placeholder="Masukkan Kata Laluan" id="passwordInputt" />
                        <button type="button" onclick="togglePasswordd()"
                            class="absolute right-3 top-3 text-gray-500 hover:text-gray-700 focus:outline-none mt-2">
                            <i id="eyeIconn" class="fas fa-eye"></i>
                        </button>
                    </div>
                </div>
                <br>


                <div>
                    <label class="text-gray-800 text-sm mb-2 block">Role</label>
                    <select name="role"
                        class="text-gray-800 bg-white border border-gray-300 w-full text-sm px-4 py-3 rounded-md outline-blue-500"
                        required>
                        <option value="Pelajar">Pelajar</option>
                        <option value="Pensyarah">Pensyarah</option>
                        <option value="Admin">Admin</option>
                    </select>
                </div>

                <div class="!mt-12">
                    <input type="submit" value="Mendaftar"
                        class="w-full py-3 px-4 text-sm tracking-wider font-semibold rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none">
                </div>
                <p class="text-gray-800 text-sm mt-6 text-center">Sudah mempunyai akaun? <a href="login.php"
                        class="text-blue-600 font-semibold hover:underline ml-1">Log Masuk Sekarang</a></p>
        </div>
        </form>
    </div>
    </div>

    <!--script-->
    <script>
        function togglePassword() {
            const passwordInput = document.getElementById("passwordInput");
            const eyeIcon = document.getElementById("eyeIcon");

            if (passwordInput.type === "password") {
                passwordInput.type = "text";
                eyeIcon.classList.remove("fa-eye");
                eyeIcon.classList.add("fa-eye-slash");
            } else {
                passwordInput.type = "password";
                eyeIcon.classList.remove("fa-eye-slash");
                eyeIcon.classList.add("fa-eye");
            }
        }

        function togglePasswordd() {
            const passwordInputt = document.getElementById("passwordInputt");
            const eyeIconn = document.getElementById("eyeIconn");

            if (passwordInputt.type === "password") {
                passwordInputt.type = "text";
                eyeIconn.classList.remove("fa-eye");
                eyeIconn.classList.add("fa-eye-slash");
            } else {
                passwordInputt.type = "password";
                eyeIconn.classList.remove("fa-eye-slash");
                eyeIconn.classList.add("fa-eye");
            }
        }
    </script>











</body>

</html>
